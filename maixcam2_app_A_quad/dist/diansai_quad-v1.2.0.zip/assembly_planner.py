"""A版拼图的毫米区域判断、布局求解、稳定缓存和目标位姿绘制。"""

import itertools
import math

import cv2
import numpy as np

try:
    from maixcam2_app_A_quad.paper_locator import (
        build_split_segment,
        paper_points_to_image_px,
        validate_split_y_mm,
        validate_work_region_mm,
    )
    from maixcam2_app_A_quad.template_store import (
        build_shape_descriptor,
        match_known_pieces,
    )
except ModuleNotFoundError as error:
    # MaixVision平铺运行时顶层包不存在，改用main.py同级模块。
    if error.name != "maixcam2_app_A_quad":
        raise
    from paper_locator import (
        build_split_segment,
        paper_points_to_image_px,
        validate_split_y_mm,
        validate_work_region_mm,
    )
    from template_store import build_shape_descriptor, match_known_pieces


KNOWN_TARGET_SIZE_MM = (100.0, 60.0)
KNOWN_LAYOUT_SIZE_TOLERANCE_MM = 15.0


class AssemblyPlacement:
    """保存单片从当前位姿移动到目标位姿所需的屏幕与机械数据。"""

    def __init__(
        self,
        piece_id,
        source_center_mm,
        target_center_mm,
        target_polygon_mm,
        rotation_delta_deg,
    ):
        """规范化编号、中心、目标轮廓和纸面内旋转增量。

        关键参数均使用完整A4左上角为原点的毫米坐标；旋转角规范到[-180,180)。
        返回值：构造函数无返回值，数据保存为公开只读约定属性。
        """
        self.piece_id = str(piece_id)
        self.source_center_mm = tuple(float(value) for value in source_center_mm)
        self.target_center_mm = tuple(float(value) for value in target_center_mm)
        self.target_polygon_mm = [
            (float(point[0]), float(point[1])) for point in target_polygon_mm
        ]
        self.rotation_delta_deg = _normalize_angle_deg(rotation_delta_deg)


class AssemblyPlan:
    """保存一次拼装求解的成功状态、目标矩形、单片位姿和诊断分数。"""

    def __init__(
        self,
        success,
        placements=None,
        target_rect_mm=None,
        score=float("inf"),
        reason="",
        search_nodes=0,
    ):
        """初始化结构化规划结果，失败结果默认不携带任何机械目标。"""
        self.success = bool(success)
        self.placements = list(placements or [])
        self.target_rect_mm = (
            None
            if target_rect_mm is None
            else tuple(float(value) for value in target_rect_mm)
        )
        self.score = float(score)
        self.reason = str(reason)
        self.search_nodes = int(search_nodes)

    @classmethod
    def failed(cls, reason, search_nodes=0):
        """构造不含目标位置的失败结果，避免调用方误驱动电机。"""
        return cls(False, reason=reason, search_nodes=search_nodes)


def _normalize_angle_deg(angle_deg):
    """把任意角度规范到[-180,180)，便于屏幕显示和电机选择短路径。"""
    angle_deg = float(angle_deg)
    while angle_deg >= 180.0:
        angle_deg -= 360.0
    while angle_deg < -180.0:
        angle_deg += 360.0
    return angle_deg


def _normalize_vertices(vertices_mm, minimum_count=3):
    """校验毫米多边形并返回N×2 float64数组。

    关键参数：minimum_count默认3；所有坐标必须有限且多边形面积非零。
    返回值：独立数组；字段缺失、退化或非二维输入抛出ValueError。
    """
    vertices = np.asarray(vertices_mm, dtype=np.float64)
    if vertices.ndim != 2 or vertices.shape[1] != 2 or len(vertices) < minimum_count:
        raise ValueError("毫米多边形必须包含至少三个二维顶点")
    if not np.all(np.isfinite(vertices)):
        raise ValueError("毫米多边形必须包含有限数字")
    if abs(float(cv2.contourArea(vertices.astype(np.float32)))) <= 1e-6:
        raise ValueError("毫米多边形面积过小或已经退化")
    return vertices.copy()


def _polygon_centroid(vertices_mm):
    """计算毫米多边形面积质心，退化时回退顶点均值。"""
    vertices = _normalize_vertices(vertices_mm)
    moments = cv2.moments(vertices.astype(np.float32).reshape(-1, 1, 2))
    if abs(float(moments["m00"])) <= 1e-9:
        center = np.mean(vertices, axis=0)
    else:
        center = np.asarray(
            (
                moments["m10"] / moments["m00"],
                moments["m01"] / moments["m00"],
            ),
            dtype=np.float64,
        )
    return float(center[0]), float(center[1])


def classify_piece_region(vertices_mm, split_y_mm, tolerance_mm=0.5):
    """按全部毫米顶点判断碎片位于分界线上方、下方或跨线。

    顶点最高Y不超过分界线减容差时为upper，最低Y不小于分界线加容差时为lower；
    其余情况统一为crossing，防止只看质心导致机械抓取跨线碎片。
    """
    vertices = _normalize_vertices(vertices_mm)
    split_y_mm = float(split_y_mm)
    tolerance_mm = max(0.0, float(tolerance_mm))
    maximum_y = float(np.max(vertices[:, 1]))
    minimum_y = float(np.min(vertices[:, 1]))
    if maximum_y <= split_y_mm - tolerance_mm:
        return "upper"
    if minimum_y >= split_y_mm + tolerance_mm:
        return "lower"
    return "crossing"


def _descriptor_sort_key(descriptor):
    """复用模板登记的稳定几何排序规则，为布局和K编号建立一一对应。"""
    return (
        int(descriptor["vertex_count"]),
        round(float(descriptor["compactness"]), 9),
        tuple(round(float(value), 9) for value in sorted(descriptor["edge_ratios"])),
    )


def register_known_layout(
    pieces,
    expected_size_mm=KNOWN_TARGET_SIZE_MM,
    size_tolerance_mm=KNOWN_LAYOUT_SIZE_TOLERANCE_MM,
):
    """把赛前正确四片布局登记为形状模板和目标局部毫米轮廓。

    主要流程：检查四片完整毫米多边形，求整体外接轴对齐矩形，确认接近100×60mm，
    再把检测坐标按两轴归一到精确目标尺寸。描述子与目标轮廓使用同一稳定排序编号。
    返回值：四个可直接交给template_store保存的模板字典。
    """
    pieces = list(pieces)
    if len(pieces) != 4:
        raise ValueError("已知布局必须恰好包含四片")
    expected_width, expected_height = (float(value) for value in expected_size_mm)
    if expected_width <= 0.0 or expected_height <= 0.0:
        raise ValueError("已知目标宽高必须大于零")

    vertices_by_piece = [_normalize_vertices(piece["vertices_mm"]) for piece in pieces]
    all_vertices = np.vstack(vertices_by_piece)
    minimum = np.min(all_vertices, axis=0)
    maximum = np.max(all_vertices, axis=0)
    measured_width, measured_height = maximum - minimum
    tolerance = max(0.0, float(size_tolerance_mm))
    if (
        abs(float(measured_width) - expected_width) > tolerance
        or abs(float(measured_height) - expected_height) > tolerance
    ):
        raise ValueError("已知布局外框必须接近100×60mm")

    scale = np.asarray(
        (expected_width / measured_width, expected_height / measured_height),
        dtype=np.float64,
    )
    candidates = []
    for piece, vertices in zip(pieces, vertices_by_piece):
        descriptor = build_shape_descriptor(piece)
        target_vertices = (vertices - minimum) * scale
        candidates.append((descriptor, target_vertices))
    candidates.sort(key=lambda item: _descriptor_sort_key(item[0]))

    templates = []
    for index, (descriptor, target_vertices) in enumerate(candidates, start=1):
        templates.append(
            {
                "id": f"K{index}",
                **descriptor,
                "target_vertices_mm": target_vertices.astype(float).tolist(),
                "layout_size_mm": [expected_width, expected_height],
            }
        )
    return templates


def _target_rect_in_lower_region(work_region_mm, split_y_mm, target_size_mm):
    """把目标矩形居中放入黄色区域下半区，空间不足时返回None。"""
    work_x, work_y, work_width, work_height = validate_work_region_mm(work_region_mm)
    split_y = validate_split_y_mm(work_region_mm, split_y_mm)
    target_width, target_height = (float(value) for value in target_size_mm)
    lower_height = work_y + work_height - split_y
    if target_width > work_width + 1e-6 or target_height > lower_height + 1e-6:
        return None
    target_x = work_x + (work_width - target_width) / 2.0
    target_y = split_y + (lower_height - target_height) / 2.0
    return target_x, target_y, target_width, target_height


def _best_rotation_delta_deg(source_vertices_mm, target_vertices_mm):
    """用不含镜像的二维刚体配准求源多边形到目标多边形的旋转增量。

    主要流程：枚举目标顶点循环起点和正反遍历，仅接受行列式为正的旋转矩阵；
    以中心化均方根误差选最佳对应。返回值：``(角度, 误差)``。
    """
    source = _normalize_vertices(source_vertices_mm)
    target = _normalize_vertices(target_vertices_mm)
    if len(source) != len(target):
        raise ValueError("刚体配准要求源和目标顶点数一致")
    source_centered = source - np.mean(source, axis=0)
    best_angle = 0.0
    best_error = float("inf")

    for traversal in (target, target[::-1]):
        for shift in range(len(target)):
            aligned_target = np.roll(traversal, shift, axis=0)
            target_centered = aligned_target - np.mean(aligned_target, axis=0)
            covariance = source_centered.T @ target_centered
            left, _, right = np.linalg.svd(covariance)
            rotation = right.T @ left.T
            if np.linalg.det(rotation) < 0.0:
                right[-1, :] *= -1.0
                rotation = right.T @ left.T
            transformed = source_centered @ rotation.T
            error = float(
                np.sqrt(np.mean(np.sum((transformed - target_centered) ** 2, axis=1)))
            )
            if error < best_error:
                best_error = error
                best_angle = math.degrees(math.atan2(rotation[1, 0], rotation[0, 0]))
    return _normalize_angle_deg(best_angle), best_error


def solve_known_layout(
    pieces,
    templates,
    work_region_mm,
    split_y_mm,
    max_match_score=1.2,
):
    """匹配已知四片并直接生成固定100×60mm下半区目标位姿。

    主要流程：检查模板布局字段，计算下半区目标框，复用最多24种全局模板分配，
    再逐片执行无镜像刚体配准。返回AssemblyPlan；任何不安全条件返回结构化失败。
    """
    pieces = list(pieces)
    templates = list(templates)
    if len(pieces) != 4 or len(templates) != 4:
        return AssemblyPlan.failed("known_needs_four")
    if any(
        "target_vertices_mm" not in template or "layout_size_mm" not in template
        for template in templates
    ):
        return AssemblyPlan.failed("template_no_layout")

    try:
        target_sizes = {
            tuple(float(value) for value in item["layout_size_mm"])
            for item in templates
        }
        if any(
            len(size) != 2
            or not np.all(np.isfinite(np.asarray(size)))
            or min(size) <= 0.0
            for size in target_sizes
        ):
            raise ValueError("目标布局尺寸无效")
        # 在模板匹配前先校验所有目标多边形，损坏持久文件只能产生失败规划，
        # 不能把ValueError泄漏到MaixCAM2主循环。
        for template in templates:
            _normalize_vertices(template["target_vertices_mm"])
    except (KeyError, TypeError, ValueError):
        return AssemblyPlan.failed("template_layout_invalid")
    if len(target_sizes) != 1:
        return AssemblyPlan.failed("template_layout_invalid")
    target_size = next(iter(target_sizes))
    try:
        target_rect = _target_rect_in_lower_region(
            work_region_mm,
            split_y_mm,
            target_size,
        )
    except ValueError:
        return AssemblyPlan.failed("target_out_of_work_region")
    if target_rect is None:
        return AssemblyPlan.failed("target_out_of_work_region")

    match_known_pieces(pieces, templates, float(max_match_score))
    if any(piece.get("id") == "UNKNOWN" for piece in pieces):
        return AssemblyPlan.failed("known_match_failed")

    template_by_id = {template["id"]: template for template in templates}
    target_origin = np.asarray(target_rect[:2], dtype=np.float64)
    placements = []
    total_score = 0.0
    for piece in pieces:
        template = template_by_id[piece["id"]]
        local_target = _normalize_vertices(template["target_vertices_mm"])
        target_polygon = local_target + target_origin
        try:
            rotation_delta, alignment_error = _best_rotation_delta_deg(
                piece["vertices_mm"],
                target_polygon,
            )
        except ValueError:
            return AssemblyPlan.failed("known_pose_failed")
        target_center = _polygon_centroid(target_polygon)
        placements.append(
            AssemblyPlacement(
                piece["id"],
                piece["center_mm"],
                target_center,
                target_polygon,
                rotation_delta,
            )
        )
        total_score += float(piece.get("match_score", 0.0)) + alignment_error * 0.01

    placements.sort(key=lambda placement: placement.piece_id)
    return AssemblyPlan(
        True,
        placements=placements,
        target_rect_mm=target_rect,
        score=total_score,
        reason="ok",
        search_nodes=24,
    )


PATTERN_ENERGY_THRESHOLD = 0.05
UNKNOWN_LONG_SIDE_RANGE_MM = (88.0, 122.0)
UNKNOWN_SHORT_SIDE_RANGE_MM = (48.0, 92.0)
UNKNOWN_MIN_FILL_RATIO = 0.92
UNKNOWN_MAX_OVERLAP_RATIO = 0.03
# 栅格边界离散会给完全正确的白片组合带来约0.6分，1.0仍远低于验收上限，
# 同时能在首个合法矩形处停止，避免无纹理候选继续跑满12000节点。
UNKNOWN_WHITE_EARLY_STOP_SCORE = 1.0


def _resample_feature(values, target_count):
    """把一维或多通道边缘样本线性重采样到统一长度。"""
    array = np.asarray(values, dtype=np.float64)
    if array.ndim not in (1, 2) or len(array) < 2:
        raise ValueError("边缘特征至少需要两个样本")
    source_positions = np.linspace(0.0, 1.0, len(array))
    target_positions = np.linspace(0.0, 1.0, int(target_count))
    if array.ndim == 1:
        return np.interp(target_positions, source_positions, array)
    channels = [
        np.interp(target_positions, source_positions, array[:, channel])
        for channel in range(array.shape[1])
    ]
    return np.column_stack(channels)


def edge_feature_match_score(first_feature, second_feature):
    """计算两条反向对接边的牌面颜色与梯度不连续分数。

    只有任一边的pattern_energy达到门槛时才启用纹理项；纯白边直接返回0。第二条边
    按拼装方向反转，切向梯度同时取反。返回值越小表示花纹越连续。
    """
    if not first_feature or not second_feature:
        return 0.0
    first_energy = float(first_feature.get("pattern_energy", 0.0))
    second_energy = float(second_feature.get("pattern_energy", 0.0))
    if max(first_energy, second_energy) < PATTERN_ENERGY_THRESHOLD:
        return 0.0
    try:
        sample_count = max(
            4,
            min(
                len(first_feature["colors"]),
                len(second_feature["colors"]),
            ),
        )
        first_colors = _resample_feature(first_feature["colors"], sample_count)
        second_colors = _resample_feature(second_feature["colors"], sample_count)[::-1]
        first_gradients = _resample_feature(first_feature["gradients"], sample_count)
        second_gradients = -_resample_feature(
            second_feature["gradients"], sample_count
        )[::-1]
    except (KeyError, TypeError, ValueError):
        return 0.0
    color_error = float(np.mean(np.abs(first_colors - second_colors))) / 255.0
    gradient_error = float(np.mean(np.abs(first_gradients - second_gradients))) / 255.0
    return color_error + 0.5 * gradient_error


def _solver_piece(piece, index):
    """把识别碎片规范为未知回溯所需的局部毫米多边形和边特征。"""
    vertices = _normalize_vertices(piece["vertices_mm"])
    center = np.asarray(_polygon_centroid(vertices), dtype=np.float64)
    features = list(piece.get("edge_features") or [])
    if features and len(features) != len(vertices):
        raise ValueError("edge_features必须与多边形边数一致")
    if not features:
        features = [None for _ in range(len(vertices))]
    return {
        "index": int(index),
        "id": str(piece.get("id", f"U{index + 1}")),
        "source_vertices": vertices,
        "local_vertices": vertices - center,
        "source_center": tuple(float(value) for value in piece.get("center_mm", center)),
        "edge_features": features,
    }


def _edge_length(vertices, edge_index):
    """返回循环多边形指定边的毫米长度。"""
    start = vertices[edge_index]
    end = vertices[(edge_index + 1) % len(vertices)]
    return float(np.linalg.norm(end - start))


def _align_source_edge_to_target(source_vertices, source_edge, target_vertices, target_edge):
    """生成使源边与目标边反向重合的无缩放、无镜像刚体变换多边形。"""
    source_start = source_vertices[source_edge]
    source_end = source_vertices[(source_edge + 1) % len(source_vertices)]
    target_start = target_vertices[target_edge]
    target_end = target_vertices[(target_edge + 1) % len(target_vertices)]
    source_vector = source_end - source_start
    target_vector = target_start - target_end
    source_angle = math.atan2(source_vector[1], source_vector[0])
    target_angle = math.atan2(target_vector[1], target_vector[0])
    angle = target_angle - source_angle
    rotation = np.asarray(
        [[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]],
        dtype=np.float64,
    )
    translation = target_end - source_start @ rotation.T
    return source_vertices @ rotation.T + translation


def _rasterize_polygons(polygons, pixels_per_mm=2.0, erode=False):
    """把毫米多边形放入共同局部画布并返回逐片二值掩膜。

    该函数支持凹多边形，专门用于小规模重叠与填充校验。erode=True时收缩一个像素，
    消除共享边因离散填充产生的单像素假重叠。
    """
    polygons = [np.asarray(polygon, dtype=np.float64) for polygon in polygons]
    all_points = np.vstack(polygons)
    minimum = np.floor(np.min(all_points, axis=0) * pixels_per_mm) - 3.0
    maximum = np.ceil(np.max(all_points, axis=0) * pixels_per_mm) + 3.0
    canvas_width = max(8, int(maximum[0] - minimum[0] + 1))
    canvas_height = max(8, int(maximum[1] - minimum[1] + 1))
    masks = []
    kernel = np.ones((3, 3), dtype=np.uint8)
    for polygon in polygons:
        pixel_polygon = np.rint(polygon * pixels_per_mm - minimum).astype(np.int32)
        mask = np.zeros((canvas_height, canvas_width), dtype=np.uint8)
        cv2.fillPoly(mask, [pixel_polygon], 255)
        if erode:
            mask = cv2.erode(mask, kernel, iterations=1)
        masks.append(mask)
    return masks


def _candidate_overlaps(candidate_polygon, placed_polygons, pixels_per_mm=2.0):
    """判断新候选与已放置碎片是否存在超过共享边离散误差的内部重叠。"""
    if not placed_polygons:
        return False
    masks = _rasterize_polygons(
        list(placed_polygons) + [candidate_polygon],
        pixels_per_mm=pixels_per_mm,
        erode=True,
    )
    existing_union = np.zeros_like(masks[0])
    for mask in masks[:-1]:
        existing_union = cv2.bitwise_or(existing_union, mask)
    overlap_pixels = int(np.count_nonzero(cv2.bitwise_and(existing_union, masks[-1])))
    candidate_pixels = max(1, int(np.count_nonzero(masks[-1])))
    return overlap_pixels / candidate_pixels > 0.01


def _canonicalize_complete_layout(placed_by_index, pixels_per_mm=2.0):
    """把完整组合旋正到长边X轴，并用栅格验证目标矩形尺寸、重叠和缝隙。

    返回值：成功时为 ``(按索引多边形字典, 宽, 高, 几何分数)``，否则为None。
    """
    indices = sorted(placed_by_index)
    polygons = [np.asarray(placed_by_index[index], dtype=np.float64) for index in indices]
    all_points = np.vstack(polygons).astype(np.float32)
    rectangle = cv2.minAreaRect(all_points.reshape(-1, 1, 2))
    center = np.asarray(rectangle[0], dtype=np.float64)
    angle = math.radians(float(rectangle[2]))
    width_axis = np.asarray((math.cos(angle), math.sin(angle)), dtype=np.float64)
    height_axis = np.asarray((-math.sin(angle), math.cos(angle)), dtype=np.float64)
    canonical = []
    for polygon in polygons:
        relative = polygon - center
        canonical.append(
            np.column_stack((relative @ width_axis, relative @ height_axis))
        )
    combined = np.vstack(canonical)
    span = np.max(combined, axis=0) - np.min(combined, axis=0)
    if span[0] < span[1]:
        # 交换轴并翻转一轴，仍保持行列式为正，避免把实体镜像。
        canonical = [np.column_stack((polygon[:, 1], -polygon[:, 0])) for polygon in canonical]
        combined = np.vstack(canonical)
    minimum = np.min(combined, axis=0)
    canonical = [polygon - minimum for polygon in canonical]
    combined = np.vstack(canonical)
    width_mm, height_mm = np.max(combined, axis=0)
    if not (
        UNKNOWN_LONG_SIDE_RANGE_MM[0] <= width_mm <= UNKNOWN_LONG_SIDE_RANGE_MM[1]
        and UNKNOWN_SHORT_SIDE_RANGE_MM[0] <= height_mm <= UNKNOWN_SHORT_SIDE_RANGE_MM[1]
    ):
        return None

    masks = _rasterize_polygons(canonical, pixels_per_mm=pixels_per_mm, erode=False)
    union = np.zeros_like(masks[0])
    total_pixels = 0
    for mask in masks:
        total_pixels += int(np.count_nonzero(mask))
        union = cv2.bitwise_or(union, mask)
    union_pixels = max(1, int(np.count_nonzero(union)))
    overlap_ratio = max(0.0, float(total_pixels - union_pixels) / float(union_pixels))

    # 在旋正后的目标外框内统计填充率，黑色缝隙和缺片都会直接降低该值。
    rectangle_pixels = max(
        1.0,
        (width_mm * pixels_per_mm + 1.0) * (height_mm * pixels_per_mm + 1.0),
    )
    fill_ratio = min(1.0, float(union_pixels) / rectangle_pixels)
    if fill_ratio < UNKNOWN_MIN_FILL_RATIO or overlap_ratio > UNKNOWN_MAX_OVERLAP_RATIO:
        return None
    geometry_score = (1.0 - fill_ratio) * 50.0 + overlap_ratio * 50.0
    return (
        {index: polygon for index, polygon in zip(indices, canonical)},
        float(width_mm),
        float(height_mm),
        float(geometry_score),
    )


def _coincident_edge(first_polygon, first_edge, second_polygon, second_edge, tolerance_mm=1.0):
    """判断两个目标边是否以反向端点在毫米容差内重合。"""
    first_start = first_polygon[first_edge]
    first_end = first_polygon[(first_edge + 1) % len(first_polygon)]
    second_start = second_polygon[second_edge]
    second_end = second_polygon[(second_edge + 1) % len(second_polygon)]
    return (
        np.linalg.norm(first_start - second_end) <= tolerance_mm
        and np.linalg.norm(first_end - second_start) <= tolerance_mm
    )


def _complete_layout_texture_score(canonical_by_index, solver_pieces):
    """汇总完整布局中所有反向重合内部边的牌面接缝分数。"""
    total_score = 0.0
    seam_count = 0
    indices = sorted(canonical_by_index)
    for first_position, first_index in enumerate(indices):
        first_polygon = canonical_by_index[first_index]
        for second_index in indices[first_position + 1 :]:
            second_polygon = canonical_by_index[second_index]
            for first_edge in range(len(first_polygon)):
                for second_edge in range(len(second_polygon)):
                    if not _coincident_edge(
                        first_polygon,
                        first_edge,
                        second_polygon,
                        second_edge,
                    ):
                        continue
                    total_score += edge_feature_match_score(
                        solver_pieces[first_index]["edge_features"][first_edge],
                        solver_pieces[second_index]["edge_features"][second_edge],
                    )
                    seam_count += 1
    return 0.0 if seam_count == 0 else total_score / seam_count


def solve_unknown_layout(
    pieces,
    work_region_mm,
    split_y_mm,
    edge_length_tolerance_mm=2.5,
    max_nodes=12000,
    pixels_per_mm=2.0,
):
    """通过等长边反向拼接回溯求解1～4片未知多边形目标矩形。

    主要流程：固定第一片消除整体自由度，枚举未放置边与已放置边的刚体对齐，
    用毫米栅格剪除重叠；完整组合通过尺寸、填充率和重叠率验收，并以牌面接缝
    连续性打破几何同分。max_nodes是硬停止条件。返回AssemblyPlan。
    """
    pieces = list(pieces)
    if not 1 <= len(pieces) <= 4:
        return AssemblyPlan.failed("unknown_piece_count")
    try:
        max_nodes = int(max_nodes)
        pixels_per_mm = float(pixels_per_mm)
        length_tolerance = float(edge_length_tolerance_mm)
        if max_nodes <= 0 or pixels_per_mm <= 0.0 or length_tolerance < 0.0:
            raise ValueError
        solver_pieces = [_solver_piece(piece, index) for index, piece in enumerate(pieces)]
    except (KeyError, TypeError, ValueError):
        return AssemblyPlan.failed("unknown_geometry_invalid")

    has_pattern = any(
        feature
        and float(feature.get("pattern_energy", 0.0)) >= PATTERN_ENERGY_THRESHOLD
        for solver_piece in solver_pieces
        for feature in solver_piece["edge_features"]
    )
    first_polygon = solver_pieces[0]["local_vertices"].copy()
    best_candidate = None
    best_score = float("inf")
    search_nodes = 0
    reached_limit = False
    stop_search = False

    def evaluate_complete(placed_by_index):
        """验收完整组合并在分数更低时保存规范化候选。"""
        nonlocal best_candidate, best_score, stop_search
        canonical_result = _canonicalize_complete_layout(
            placed_by_index,
            pixels_per_mm=pixels_per_mm,
        )
        if canonical_result is None:
            return
        canonical_by_index, width_mm, height_mm, geometry_score = canonical_result
        texture_score = _complete_layout_texture_score(
            canonical_by_index,
            solver_pieces,
        )
        score = geometry_score + texture_score * 20.0
        if score < best_score:
            best_score = score
            best_candidate = (canonical_by_index, width_mm, height_mm)
            # 白片没有纹理同分问题，首个近乎无缝矩形即可结束以保障实时性。
            if not has_pattern and geometry_score <= UNKNOWN_WHITE_EARLY_STOP_SCORE:
                stop_search = True

    def search(placed_by_index, remaining_indices):
        """递归枚举边对齐候选，所有节点计数和停止标志由外层闭包统一管理。"""
        nonlocal search_nodes, reached_limit
        if stop_search or reached_limit:
            return
        if not remaining_indices:
            evaluate_complete(placed_by_index)
            return

        for source_index in tuple(remaining_indices):
            source_polygon = solver_pieces[source_index]["local_vertices"]
            source_lengths = [
                _edge_length(source_polygon, edge_index)
                for edge_index in range(len(source_polygon))
            ]
            for target_index, target_polygon in tuple(placed_by_index.items()):
                for target_edge in range(len(target_polygon)):
                    target_length = _edge_length(target_polygon, target_edge)
                    for source_edge, source_length in enumerate(source_lengths):
                        tolerance = max(length_tolerance, 0.04 * max(source_length, target_length))
                        if abs(source_length - target_length) > tolerance:
                            continue
                        search_nodes += 1
                        if search_nodes > max_nodes:
                            search_nodes = max_nodes
                            reached_limit = True
                            return
                        candidate_polygon = _align_source_edge_to_target(
                            source_polygon,
                            source_edge,
                            target_polygon,
                            target_edge,
                        )
                        if _candidate_overlaps(
                            candidate_polygon,
                            list(placed_by_index.values()),
                            pixels_per_mm=pixels_per_mm,
                        ):
                            continue
                        updated = dict(placed_by_index)
                        updated[source_index] = candidate_polygon
                        search(
                            updated,
                            tuple(index for index in remaining_indices if index != source_index),
                        )
                        if stop_search or reached_limit:
                            return

    search({0: first_polygon}, tuple(range(1, len(solver_pieces))))
    if best_candidate is None:
        reason = "search_limit" if reached_limit else "no_assembly"
        return AssemblyPlan.failed(reason, search_nodes=search_nodes)

    canonical_by_index, target_width, target_height = best_candidate
    target_rect = _target_rect_in_lower_region(
        work_region_mm,
        split_y_mm,
        (target_width, target_height),
    )
    if target_rect is None:
        return AssemblyPlan.failed("target_out_of_work_region", search_nodes=search_nodes)
    target_origin = np.asarray(target_rect[:2], dtype=np.float64)
    placements = []
    for index, solver_piece in enumerate(solver_pieces):
        target_polygon = canonical_by_index[index] + target_origin
        rotation_delta, _ = _best_rotation_delta_deg(
            solver_piece["source_vertices"],
            target_polygon,
        )
        placements.append(
            AssemblyPlacement(
                solver_piece["id"],
                solver_piece["source_center"],
                _polygon_centroid(target_polygon),
                target_polygon,
                rotation_delta,
            )
        )
    placements.sort(key=lambda placement: placement.piece_id)
    return AssemblyPlan(
        True,
        placements=placements,
        target_rect_mm=target_rect,
        score=best_score,
        reason="ok",
        search_nodes=search_nodes,
    )


def _template_context_fingerprint(templates):
    """生成只包含编号和目标轮廓的稳定模板指纹，供缓存检测布局变化。"""
    fingerprint = []
    for template in templates:
        target_vertices = template.get("target_vertices_mm")
        normalized_vertices = None
        if target_vertices is not None:
            normalized_vertices = tuple(
                tuple(round(float(value), 3) for value in point)
                for point in target_vertices
            )
        fingerprint.append((str(template.get("id", "")), normalized_vertices))
    return tuple(sorted(fingerprint))


def _piece_observation(piece):
    """提取稳定帧比较所需的顶点数、毫米中心和有序毫米顶点。"""
    vertices = _normalize_vertices(piece["vertices_mm"])
    center = tuple(float(value) for value in piece.get("center_mm", _polygon_centroid(vertices)))
    return {
        "vertex_count": len(vertices),
        "center": np.asarray(center, dtype=np.float64),
        "vertices": vertices,
    }


def _polygon_frame_distance(first_vertices, second_vertices):
    """枚举循环起点和遍历方向，计算两帧同片顶点的最小RMS毫米位移。"""
    if len(first_vertices) != len(second_vertices):
        return float("inf")
    best_distance = float("inf")
    for traversal in (second_vertices, second_vertices[::-1]):
        for shift in range(len(second_vertices)):
            aligned = np.roll(traversal, shift, axis=0)
            distance = float(
                np.sqrt(np.mean(np.sum((first_vertices - aligned) ** 2, axis=1)))
            )
            best_distance = min(best_distance, distance)
    return best_distance


def _observations_are_stable(reference, current, tolerance_mm):
    """对不超过四片的两帧观测穷举一对一对应，判断全部顶点位移是否在容差内。"""
    if len(reference) != len(current):
        return False
    for assignment in itertools.permutations(range(len(current))):
        assignment_valid = True
        for reference_index, current_index in enumerate(assignment):
            first = reference[reference_index]
            second = current[current_index]
            if first["vertex_count"] != second["vertex_count"]:
                assignment_valid = False
                break
            if np.linalg.norm(first["center"] - second["center"]) > tolerance_mm:
                assignment_valid = False
                break
            if _polygon_frame_distance(first["vertices"], second["vertices"]) > tolerance_mm:
                assignment_valid = False
                break
        if assignment_valid:
            return True
    return False


class AssemblyRuntime:
    """维护连续稳定帧门、一次求解和跨帧缓存。

    规划缓存用于机械开始移动后的画面：碎片位置变化不会触发重算；识别模式、模板、
    黄色机械区域或分界线变化会自动建立新上下文并清除旧目标。
    """

    def __init__(self, stable_frames=3, position_tolerance_mm=2.0):
        """初始化稳定帧数量和毫米容差，两个参数必须为正数。"""
        self.stable_frames = int(stable_frames)
        self.position_tolerance_mm = float(position_tolerance_mm)
        if self.stable_frames <= 0 or self.position_tolerance_mm <= 0.0:
            raise ValueError("稳定帧数量和位置容差必须大于零")
        self.solve_count = 0
        self._context_key = None
        self._reference_observation = None
        self.stable_count = 0
        self.plan = None

    def reset(self):
        """清除上下文、稳定累计和规划缓存，但保留生命周期求解计数供诊断。"""
        self._context_key = None
        self._reference_observation = None
        self.stable_count = 0
        self.plan = None

    def _reset_tracking(self):
        """上下文变化时只清除帧跟踪和目标，随后由当前帧立即重新累计。"""
        self._reference_observation = None
        self.stable_count = 0
        self.plan = None

    def update(
        self,
        mode,
        pieces,
        templates,
        work_region_mm,
        split_y_mm,
        known_match_threshold=1.2,
        unknown_max_nodes=12000,
    ):
        """接收一帧识别数据，在稳定门满足后求解一次并返回缓存。

        关键参数：mode为known或unknown；只使用complete且region=upper的1～4片。
        返回值：累计期间为None，求解后为成功或失败AssemblyPlan，后续帧返回同一对象。
        """
        mode = str(mode).lower()
        if mode not in ("known", "unknown"):
            raise ValueError("规划模式必须是known或unknown")
        work_region = validate_work_region_mm(work_region_mm)
        split_y = validate_split_y_mm(work_region, split_y_mm)
        template_key = _template_context_fingerprint(templates) if mode == "known" else ()
        context_key = (
            mode,
            tuple(round(float(value), 3) for value in work_region),
            round(split_y, 3),
            template_key,
        )
        if context_key != self._context_key:
            self._context_key = context_key
            self._reset_tracking()
        if self.plan is not None:
            return self.plan

        actionable = [
            piece
            for piece in pieces
            if piece.get("complete") is True and piece.get("region") == "upper"
        ]
        if not 1 <= len(actionable) <= 4:
            self._reference_observation = None
            self.stable_count = 0
            return None
        try:
            current_observation = [_piece_observation(piece) for piece in actionable]
        except (KeyError, TypeError, ValueError):
            self._reference_observation = None
            self.stable_count = 0
            return None

        if self._reference_observation is None:
            self.stable_count = 1
        elif _observations_are_stable(
            self._reference_observation,
            current_observation,
            self.position_tolerance_mm,
        ):
            self.stable_count += 1
        else:
            self.stable_count = 1
        self._reference_observation = current_observation
        if self.stable_count < self.stable_frames:
            return None

        self.solve_count += 1
        if mode == "known":
            self.plan = solve_known_layout(
                actionable,
                templates,
                work_region,
                split_y,
                max_match_score=known_match_threshold,
            )
        else:
            self.plan = solve_unknown_layout(
                actionable,
                work_region,
                split_y,
                max_nodes=unknown_max_nodes,
            )
        return self.plan


COLOR_PLAN_SPLIT = (0, 0, 255)
COLOR_PLAN_TARGET = (255, 0, 255)
COLOR_PLAN_ARROW = (0, 165, 255)
COLOR_PLAN_PIECES = (
    (0, 255, 0),
    (255, 180, 0),
    (0, 220, 220),
    (220, 100, 255),
)


def _rect_corners(rect_mm):
    """把X/Y/W/H目标矩形转换为顺时针四个毫米角点。"""
    rect_x, rect_y, rect_width, rect_height = (float(value) for value in rect_mm)
    return np.asarray(
        (
            (rect_x, rect_y),
            (rect_x + rect_width, rect_y),
            (rect_x + rect_width, rect_y + rect_height),
            (rect_x, rect_y + rect_height),
        ),
        dtype=np.float32,
    )


def draw_assembly_plan(frame_bgr, plan, paper_quad, work_region_mm, split_y_mm):
    """在相机画面副本上绘制毫米分界线、目标矩形、单片轮廓、箭头和位姿文字。

    失败或尚未求解时仍绘制红色分界线；只有成功plan才输出机械目标。所有毫米点
    通过完整A4单应性映射，输入frame_bgr保持不变。返回值：同尺寸BGR新图像。
    """
    if frame_bgr is None or not isinstance(frame_bgr, np.ndarray):
        raise ValueError("frame_bgr必须是有效numpy图像")
    output = frame_bgr.copy()
    split_segment = build_split_segment(paper_quad, work_region_mm, split_y_mm)
    cv2.line(
        output,
        tuple(np.rint(split_segment[0]).astype(np.int32)),
        tuple(np.rint(split_segment[1]).astype(np.int32)),
        COLOR_PLAN_SPLIT,
        2,
    )
    if plan is None or not plan.success or plan.target_rect_mm is None:
        return output

    target_rect_px = paper_points_to_image_px(
        _rect_corners(plan.target_rect_mm),
        paper_quad,
    )
    for index, placement in enumerate(plan.placements):
        color = COLOR_PLAN_PIECES[index % len(COLOR_PLAN_PIECES)]
        target_polygon_px = paper_points_to_image_px(
            placement.target_polygon_mm,
            paper_quad,
        )
        source_center_px = paper_points_to_image_px(
            [placement.source_center_mm],
            paper_quad,
        )[0]
        target_center_px = paper_points_to_image_px(
            [placement.target_center_mm],
            paper_quad,
        )[0]
        target_polygon_int = np.rint(target_polygon_px).astype(np.int32)
        source_center_int = tuple(np.rint(source_center_px).astype(np.int32))
        target_center_int = tuple(np.rint(target_center_px).astype(np.int32))
        cv2.polylines(output, [target_polygon_int], True, color, 2)
        cv2.arrowedLine(
            output,
            source_center_int,
            target_center_int,
            COLOR_PLAN_ARROW,
            2,
            tipLength=0.12,
        )
        label = (
            f"{placement.piece_id} "
            f"({placement.target_center_mm[0]:.1f},{placement.target_center_mm[1]:.1f}) "
            f"R{placement.rotation_delta_deg:+.1f}"
        )
        cv2.putText(
            output,
            label,
            (max(0, target_center_int[0] + 4), max(14, target_center_int[1] - 4)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.38,
            color,
            1,
            cv2.LINE_AA,
        )
    # 总目标外框最后绘制，避免单片轮廓与外框重合时把矩形边界完全覆盖。
    cv2.polylines(
        output,
        [np.rint(target_rect_px).astype(np.int32)],
        True,
        COLOR_PLAN_TARGET,
        2,
    )
    return output
