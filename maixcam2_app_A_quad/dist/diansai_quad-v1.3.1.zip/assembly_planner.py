"""A版拼图的毫米区域判断、布局求解、稳定缓存和目标位姿绘制。"""

import itertools
import math
import time

import cv2
import numpy as np

try:
    from maixcam2_app_A_quad.paper_locator import (
        build_split_segment,
        paper_points_to_image_px,
        validate_split_y_mm,
        validate_work_region_mm,
    )
    from maixcam2_app_A_quad.template_store import (
        build_shape_descriptor,
        match_known_pieces,
    )
except ModuleNotFoundError as error:
    # MaixVision平铺运行时顶层包不存在，改用main.py同级模块。
    if error.name != "maixcam2_app_A_quad":
        raise
    from paper_locator import (
        build_split_segment,
        paper_points_to_image_px,
        validate_split_y_mm,
        validate_work_region_mm,
    )
    from template_store import build_shape_descriptor, match_known_pieces


KNOWN_TARGET_SIZE_MM = (100.0, 60.0)
KNOWN_LAYOUT_SIZE_TOLERANCE_MM = 15.0


class AssemblyPlacement:
    """保存单片从当前位姿移动到目标位姿所需的屏幕与机械数据。"""

    def __init__(
        self,
        piece_id,
        source_center_mm,
        target_center_mm,
        target_polygon_mm,
        rotation_delta_deg,
    ):
        """规范化编号、中心、目标轮廓和纸面内旋转增量。

        关键参数均使用完整A4左上角为原点的毫米坐标；旋转角规范到[-180,180)。
        返回值：构造函数无返回值，数据保存为公开只读约定属性。
        """
        self.piece_id = str(piece_id)
        self.source_center_mm = tuple(float(value) for value in source_center_mm)
        self.target_center_mm = tuple(float(value) for value in target_center_mm)
        self.target_polygon_mm = [
            (float(point[0]), float(point[1])) for point in target_polygon_mm
        ]
        self.rotation_delta_deg = _normalize_angle_deg(rotation_delta_deg)


class AssemblyPlan:
    """保存一次拼装求解的成功状态、目标矩形、单片位姿和诊断分数。"""

    def __init__(
        self,
        success,
        placements=None,
        target_rect_mm=None,
        score=float("inf"),
        reason="",
        search_nodes=0,
        diagnostics=None,
    ):
        """初始化结构化规划结果，失败结果默认不携带任何机械目标。

        diagnostics保存搜索阶段的拒绝次数，只用于屏幕和测试诊断，不参与电机控制。
        """
        self.success = bool(success)
        self.placements = list(placements or [])
        self.target_rect_mm = (
            None
            if target_rect_mm is None
            else tuple(float(value) for value in target_rect_mm)
        )
        self.score = float(score)
        self.reason = str(reason)
        self.search_nodes = int(search_nodes)
        self.diagnostics = {
            str(name): int(count) for name, count in (diagnostics or {}).items()
        }

    @classmethod
    def failed(cls, reason, search_nodes=0, diagnostics=None):
        """构造不含目标位置的失败结果，避免调用方误驱动电机。"""
        return cls(
            False,
            reason=reason,
            search_nodes=search_nodes,
            diagnostics=diagnostics,
        )


def _normalize_angle_deg(angle_deg):
    """把任意角度规范到[-180,180)，便于屏幕显示和电机选择短路径。"""
    angle_deg = float(angle_deg)
    while angle_deg >= 180.0:
        angle_deg -= 360.0
    while angle_deg < -180.0:
        angle_deg += 360.0
    return angle_deg


def _normalize_vertices(vertices_mm, minimum_count=3):
    """校验毫米多边形并返回N×2 float64数组。

    关键参数：minimum_count默认3；所有坐标必须有限且多边形面积非零。
    返回值：独立数组；字段缺失、退化或非二维输入抛出ValueError。
    """
    vertices = np.asarray(vertices_mm, dtype=np.float64)
    if vertices.ndim != 2 or vertices.shape[1] != 2 or len(vertices) < minimum_count:
        raise ValueError("毫米多边形必须包含至少三个二维顶点")
    if not np.all(np.isfinite(vertices)):
        raise ValueError("毫米多边形必须包含有限数字")
    if abs(float(cv2.contourArea(vertices.astype(np.float32)))) <= 1e-6:
        raise ValueError("毫米多边形面积过小或已经退化")
    return vertices.copy()


def _polygon_centroid(vertices_mm):
    """计算毫米多边形面积质心，退化时回退顶点均值。"""
    vertices = _normalize_vertices(vertices_mm)
    moments = cv2.moments(vertices.astype(np.float32).reshape(-1, 1, 2))
    if abs(float(moments["m00"])) <= 1e-9:
        center = np.mean(vertices, axis=0)
    else:
        center = np.asarray(
            (
                moments["m10"] / moments["m00"],
                moments["m01"] / moments["m00"],
            ),
            dtype=np.float64,
        )
    return float(center[0]), float(center[1])


def classify_piece_region(vertices_mm, split_y_mm, tolerance_mm=0.5):
    """按全部毫米顶点判断碎片位于分界线上方、下方或跨线。

    顶点最高Y不超过分界线减容差时为upper，最低Y不小于分界线加容差时为lower；
    其余情况统一为crossing，防止只看质心导致机械抓取跨线碎片。
    """
    vertices = _normalize_vertices(vertices_mm)
    split_y_mm = float(split_y_mm)
    tolerance_mm = max(0.0, float(tolerance_mm))
    maximum_y = float(np.max(vertices[:, 1]))
    minimum_y = float(np.min(vertices[:, 1]))
    if maximum_y <= split_y_mm - tolerance_mm:
        return "upper"
    if minimum_y >= split_y_mm + tolerance_mm:
        return "lower"
    return "crossing"


def _descriptor_sort_key(descriptor):
    """复用模板登记的稳定几何排序规则，为布局和K编号建立一一对应。"""
    return (
        int(descriptor["vertex_count"]),
        round(float(descriptor["compactness"]), 9),
        tuple(round(float(value), 9) for value in sorted(descriptor["edge_ratios"])),
    )


def register_known_layout(
    pieces,
    expected_size_mm=KNOWN_TARGET_SIZE_MM,
    size_tolerance_mm=KNOWN_LAYOUT_SIZE_TOLERANCE_MM,
):
    """把赛前正确四片布局登记为形状模板和目标局部毫米轮廓。

    主要流程：检查四片完整毫米多边形，求整体外接轴对齐矩形，确认接近100×60mm，
    再把检测坐标按两轴归一到精确目标尺寸。描述子与目标轮廓使用同一稳定排序编号。
    返回值：四个可直接交给template_store保存的模板字典。
    """
    pieces = list(pieces)
    if len(pieces) != 4:
        raise ValueError("已知布局必须恰好包含四片")
    expected_width, expected_height = (float(value) for value in expected_size_mm)
    if expected_width <= 0.0 or expected_height <= 0.0:
        raise ValueError("已知目标宽高必须大于零")

    vertices_by_piece = [_normalize_vertices(piece["vertices_mm"]) for piece in pieces]
    all_vertices = np.vstack(vertices_by_piece)
    minimum = np.min(all_vertices, axis=0)
    maximum = np.max(all_vertices, axis=0)
    measured_width, measured_height = maximum - minimum
    tolerance = max(0.0, float(size_tolerance_mm))
    if (
        abs(float(measured_width) - expected_width) > tolerance
        or abs(float(measured_height) - expected_height) > tolerance
    ):
        raise ValueError("已知布局外框必须接近100×60mm")

    scale = np.asarray(
        (expected_width / measured_width, expected_height / measured_height),
        dtype=np.float64,
    )
    candidates = []
    for piece, vertices in zip(pieces, vertices_by_piece):
        descriptor = build_shape_descriptor(piece)
        target_vertices = (vertices - minimum) * scale
        candidates.append((descriptor, target_vertices))
    candidates.sort(key=lambda item: _descriptor_sort_key(item[0]))

    templates = []
    for index, (descriptor, target_vertices) in enumerate(candidates, start=1):
        templates.append(
            {
                "id": f"K{index}",
                **descriptor,
                "target_vertices_mm": target_vertices.astype(float).tolist(),
                "layout_size_mm": [expected_width, expected_height],
            }
        )
    return templates


def _target_rect_in_lower_region(work_region_mm, split_y_mm, target_size_mm):
    """把目标矩形居中放入黄色区域下半区，空间不足时返回None。"""
    work_x, work_y, work_width, work_height = validate_work_region_mm(work_region_mm)
    split_y = validate_split_y_mm(work_region_mm, split_y_mm)
    target_width, target_height = (float(value) for value in target_size_mm)
    lower_height = work_y + work_height - split_y
    if target_width > work_width + 1e-6 or target_height > lower_height + 1e-6:
        return None
    target_x = work_x + (work_width - target_width) / 2.0
    target_y = split_y + (lower_height - target_height) / 2.0
    return target_x, target_y, target_width, target_height


def _best_rotation_delta_deg(source_vertices_mm, target_vertices_mm):
    """用不含镜像的二维刚体配准求源多边形到目标多边形的旋转增量。

    主要流程：枚举目标顶点循环起点和正反遍历，仅接受行列式为正的旋转矩阵；
    以中心化均方根误差选最佳对应。返回值：``(角度, 误差)``。
    """
    source = _normalize_vertices(source_vertices_mm)
    target = _normalize_vertices(target_vertices_mm)
    if len(source) != len(target):
        raise ValueError("刚体配准要求源和目标顶点数一致")
    source_centered = source - np.mean(source, axis=0)
    best_angle = 0.0
    best_error = float("inf")

    for traversal in (target, target[::-1]):
        for shift in range(len(target)):
            aligned_target = np.roll(traversal, shift, axis=0)
            target_centered = aligned_target - np.mean(aligned_target, axis=0)
            covariance = source_centered.T @ target_centered
            left, _, right = np.linalg.svd(covariance)
            rotation = right.T @ left.T
            if np.linalg.det(rotation) < 0.0:
                right[-1, :] *= -1.0
                rotation = right.T @ left.T
            transformed = source_centered @ rotation.T
            error = float(
                np.sqrt(np.mean(np.sum((transformed - target_centered) ** 2, axis=1)))
            )
            if error < best_error:
                best_error = error
                best_angle = math.degrees(math.atan2(rotation[1, 0], rotation[0, 0]))
    return _normalize_angle_deg(best_angle), best_error


def solve_known_layout(
    pieces,
    templates,
    work_region_mm,
    split_y_mm,
    max_match_score=1.2,
):
    """匹配已知四片并直接生成固定100×60mm下半区目标位姿。

    主要流程：检查模板布局字段，计算下半区目标框，复用最多24种全局模板分配，
    再逐片执行无镜像刚体配准。返回AssemblyPlan；任何不安全条件返回结构化失败。
    """
    pieces = list(pieces)
    templates = list(templates)
    if len(pieces) != 4 or len(templates) != 4:
        return AssemblyPlan.failed("known_needs_four")
    if any(
        "target_vertices_mm" not in template or "layout_size_mm" not in template
        for template in templates
    ):
        return AssemblyPlan.failed("template_no_layout")

    try:
        target_sizes = {
            tuple(float(value) for value in item["layout_size_mm"])
            for item in templates
        }
        if any(
            len(size) != 2
            or not np.all(np.isfinite(np.asarray(size)))
            or min(size) <= 0.0
            for size in target_sizes
        ):
            raise ValueError("目标布局尺寸无效")
        # 在模板匹配前先校验所有目标多边形，损坏持久文件只能产生失败规划，
        # 不能把ValueError泄漏到MaixCAM2主循环。
        for template in templates:
            _normalize_vertices(template["target_vertices_mm"])
    except (KeyError, TypeError, ValueError):
        return AssemblyPlan.failed("template_layout_invalid")
    if len(target_sizes) != 1:
        return AssemblyPlan.failed("template_layout_invalid")
    target_size = next(iter(target_sizes))
    try:
        target_rect = _target_rect_in_lower_region(
            work_region_mm,
            split_y_mm,
            target_size,
        )
    except ValueError:
        return AssemblyPlan.failed("target_out_of_work_region")
    if target_rect is None:
        return AssemblyPlan.failed("target_out_of_work_region")

    match_known_pieces(pieces, templates, float(max_match_score))
    if any(piece.get("id") == "UNKNOWN" for piece in pieces):
        return AssemblyPlan.failed("known_match_failed")

    template_by_id = {template["id"]: template for template in templates}
    target_origin = np.asarray(target_rect[:2], dtype=np.float64)
    placements = []
    total_score = 0.0
    for piece in pieces:
        template = template_by_id[piece["id"]]
        local_target = _normalize_vertices(template["target_vertices_mm"])
        target_polygon = local_target + target_origin
        try:
            rotation_delta, alignment_error = _best_rotation_delta_deg(
                piece["vertices_mm"],
                target_polygon,
            )
        except ValueError:
            return AssemblyPlan.failed("known_pose_failed")
        target_center = _polygon_centroid(target_polygon)
        placements.append(
            AssemblyPlacement(
                piece["id"],
                piece["center_mm"],
                target_center,
                target_polygon,
                rotation_delta,
            )
        )
        total_score += float(piece.get("match_score", 0.0)) + alignment_error * 0.01

    placements.sort(key=lambda placement: placement.piece_id)
    return AssemblyPlan(
        True,
        placements=placements,
        target_rect_mm=target_rect,
        score=total_score,
        reason="ok",
        search_nodes=24,
    )


PATTERN_ENERGY_THRESHOLD = 0.05
UNKNOWN_LONG_SIDE_RANGE_MM = (88.0, 122.0)
UNKNOWN_SHORT_SIDE_RANGE_MM = (48.0, 92.0)
UNKNOWN_MIN_FILL_RATIO = 0.92
UNKNOWN_MAX_OVERLAP_RATIO = 0.03
# 题目保证现场碎片的实体边不短于20mm。识别顶点存在毫米级误差，因此搜索时
# 接受18mm以上的公共接缝，既覆盖题目下限，也避免把拟合产生的短毛刺当成接缝。
UNKNOWN_MIN_SEAM_LENGTH_MM = 18.0
# 白片没有花纹对应关系，任意通过尺寸、填充和重叠硬验收的矩形都是可执行答案。
# 理论最高合格几何分为(1-0.92)*50+0.03*50=5.5，因此首个合格解即可停止。
UNKNOWN_WHITE_EARLY_STOP_SCORE = 5.5


def _resample_feature(values, target_count):
    """把一维或多通道边缘样本线性重采样到统一长度。"""
    array = np.asarray(values, dtype=np.float64)
    if array.ndim not in (1, 2) or len(array) < 2:
        raise ValueError("边缘特征至少需要两个样本")
    source_positions = np.linspace(0.0, 1.0, len(array))
    target_positions = np.linspace(0.0, 1.0, int(target_count))
    if array.ndim == 1:
        return np.interp(target_positions, source_positions, array)
    channels = [
        np.interp(target_positions, source_positions, array[:, channel])
        for channel in range(array.shape[1])
    ]
    return np.column_stack(channels)


def edge_feature_match_score(first_feature, second_feature):
    """计算两条反向对接边的牌面颜色与梯度不连续分数。

    只有任一边的pattern_energy达到门槛时才启用纹理项；纯白边直接返回0。第二条边
    按拼装方向反转，切向梯度同时取反。返回值越小表示花纹越连续。
    """
    if not first_feature or not second_feature:
        return 0.0
    first_energy = float(first_feature.get("pattern_energy", 0.0))
    second_energy = float(second_feature.get("pattern_energy", 0.0))
    if max(first_energy, second_energy) < PATTERN_ENERGY_THRESHOLD:
        return 0.0
    try:
        sample_count = max(
            4,
            min(
                len(first_feature["colors"]),
                len(second_feature["colors"]),
            ),
        )
        first_colors = _resample_feature(first_feature["colors"], sample_count)
        second_colors = _resample_feature(second_feature["colors"], sample_count)[::-1]
        first_gradients = _resample_feature(first_feature["gradients"], sample_count)
        second_gradients = -_resample_feature(
            second_feature["gradients"], sample_count
        )[::-1]
    except (KeyError, TypeError, ValueError):
        return 0.0
    color_error = float(np.mean(np.abs(first_colors - second_colors))) / 255.0
    gradient_error = float(np.mean(np.abs(first_gradients - second_gradients))) / 255.0
    return color_error + 0.5 * gradient_error


def _solver_piece(piece, index):
    """把识别碎片规范为未知回溯所需的局部毫米多边形和边特征。"""
    vertices = _normalize_vertices(piece["vertices_mm"])
    center = np.asarray(_polygon_centroid(vertices), dtype=np.float64)
    features = list(piece.get("edge_features") or [])
    if features and len(features) != len(vertices):
        raise ValueError("edge_features必须与多边形边数一致")
    if not features:
        features = [None for _ in range(len(vertices))]
    return {
        "index": int(index),
        "id": str(piece.get("id", f"U{index + 1}")),
        "source_vertices": vertices,
        "local_vertices": vertices - center,
        "source_center": tuple(float(value) for value in piece.get("center_mm", center)),
        "edge_features": features,
    }


def _edge_length(vertices, edge_index):
    """返回循环多边形指定边的毫米长度。"""
    start = vertices[edge_index]
    end = vertices[(edge_index + 1) % len(vertices)]
    return float(np.linalg.norm(end - start))


def _align_source_edge_to_target(source_vertices, source_edge, target_vertices, target_edge):
    """生成使源边与目标边反向重合的无缩放、无镜像刚体变换多边形。"""
    source_start = source_vertices[source_edge]
    source_end = source_vertices[(source_edge + 1) % len(source_vertices)]
    target_start = target_vertices[target_edge]
    target_end = target_vertices[(target_edge + 1) % len(target_vertices)]
    source_vector = source_end - source_start
    target_vector = target_start - target_end
    source_angle = math.atan2(source_vector[1], source_vector[0])
    target_angle = math.atan2(target_vector[1], target_vector[0])
    angle = target_angle - source_angle
    rotation = np.asarray(
        [[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]],
        dtype=np.float64,
    )
    translation = target_end - source_start @ rotation.T
    return source_vertices @ rotation.T + translation


def _align_source_edge_candidates(
    source_vertices,
    source_edge,
    target_vertices,
    target_edge,
):
    """生成源边与目标边反向共线时从两个端点开始对接的刚体候选。

    主要流程：先计算不缩放、不镜像的旋转，再分别让“源起点对目标终点”和
    “源终点对目标起点”。等长边的两个结果相同，会自动去重；边长不等时两个
    结果分别覆盖长边左端和右端，允许一条长边由多条短边共同组成接缝。
    返回值：一至两个保持源多边形形状不变的N×2候选数组。
    """
    source_start = source_vertices[source_edge]
    source_end = source_vertices[(source_edge + 1) % len(source_vertices)]
    target_start = target_vertices[target_edge]
    target_end = target_vertices[(target_edge + 1) % len(target_vertices)]
    source_vector = source_end - source_start
    target_reverse_vector = target_start - target_end
    source_angle = math.atan2(source_vector[1], source_vector[0])
    target_angle = math.atan2(target_reverse_vector[1], target_reverse_vector[0])
    angle = target_angle - source_angle
    rotation = np.asarray(
        [[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]],
        dtype=np.float64,
    )
    rotated_polygon = source_vertices @ rotation.T
    rotated_start = rotated_polygon[source_edge]
    rotated_end = rotated_polygon[(source_edge + 1) % len(source_vertices)]
    candidates = [rotated_polygon + (target_end - rotated_start)]
    anchored_at_start = rotated_polygon + (target_start - rotated_end)
    if not np.allclose(candidates[0], anchored_at_start, atol=1e-6):
        candidates.append(anchored_at_start)
    return candidates


def _segmented_seam_is_possible(
    solver_pieces,
    source_index,
    source_length,
    target_index,
    target_length,
    base_tolerance_mm,
):
    """判断一条长边能否由当前短边和其他碎片的边共同完整覆盖。

    主要流程：把较短边作为已占用接缝，再从其余每片最多选择一条边累加；只有
    某个组合与长边长度在毫米误差内一致时才允许分段候选进入回溯。该边长守恒
    剪枝可保留T形接缝，同时阻止任意长短边组合造成搜索节点爆炸。
    返回值：存在可完成的分段组合时为True，否则为False。
    """
    long_length = max(float(source_length), float(target_length))
    short_length = min(float(source_length), float(target_length))
    if short_length < UNKNOWN_MIN_SEAM_LENGTH_MM:
        return False

    # 每个列表项保存“当前累计长度、已经使用的接缝段数”。初始短边算一段。
    partial_sums = [(short_length, 1)]
    for piece_index, solver_piece in enumerate(solver_pieces):
        if piece_index in (source_index, target_index):
            continue
        edge_lengths = [
            _edge_length(solver_piece["local_vertices"], edge_index)
            for edge_index in range(len(solver_piece["local_vertices"]))
        ]
        next_sums = list(partial_sums)
        for current_sum, segment_count in partial_sums:
            for edge_length in edge_lengths:
                candidate_sum = current_sum + edge_length
                candidate_count = segment_count + 1
                tolerance = max(
                    float(base_tolerance_mm) * candidate_count,
                    0.06 * long_length,
                )
                if abs(candidate_sum - long_length) <= tolerance:
                    return True
                if candidate_sum < long_length + tolerance:
                    next_sums.append((candidate_sum, candidate_count))
        partial_sums = next_sums
    return False


def _rasterize_polygons(polygons, pixels_per_mm=2.0, erode=False):
    """把毫米多边形放入共同局部画布并返回逐片二值掩膜。

    该函数支持凹多边形，专门用于小规模重叠与填充校验。erode=True时收缩一个像素，
    消除共享边因离散填充产生的单像素假重叠。
    """
    polygons = [np.asarray(polygon, dtype=np.float64) for polygon in polygons]
    all_points = np.vstack(polygons)
    minimum = np.floor(np.min(all_points, axis=0) * pixels_per_mm) - 3.0
    maximum = np.ceil(np.max(all_points, axis=0) * pixels_per_mm) + 3.0
    canvas_width = max(8, int(maximum[0] - minimum[0] + 1))
    canvas_height = max(8, int(maximum[1] - minimum[1] + 1))
    masks = []
    kernel = np.ones((3, 3), dtype=np.uint8)
    for polygon in polygons:
        pixel_polygon = np.rint(polygon * pixels_per_mm - minimum).astype(np.int32)
        mask = np.zeros((canvas_height, canvas_width), dtype=np.uint8)
        cv2.fillPoly(mask, [pixel_polygon], 255)
        if erode:
            mask = cv2.erode(mask, kernel, iterations=1)
        masks.append(mask)
    return masks


def _candidate_overlaps(candidate_polygon, placed_polygons, pixels_per_mm=2.0):
    """判断新候选与已放置碎片是否存在超过共享边离散误差的内部重叠。"""
    if not placed_polygons:
        return False
    masks = _rasterize_polygons(
        list(placed_polygons) + [candidate_polygon],
        pixels_per_mm=pixels_per_mm,
        erode=True,
    )
    existing_union = np.zeros_like(masks[0])
    for mask in masks[:-1]:
        existing_union = cv2.bitwise_or(existing_union, mask)
    overlap_pixels = int(np.count_nonzero(cv2.bitwise_and(existing_union, masks[-1])))
    candidate_pixels = max(1, int(np.count_nonzero(masks[-1])))
    return overlap_pixels / candidate_pixels > 0.01


def _partial_layout_priority(
    placed_polygons,
    tolerance_mm=3.0,
    target_size_hint_mm=None,
):
    """计算部分布局的紧凑搜索优先级，并拒绝不可能装入最大目标框的状态。

    主要流程：先用点集直径和凸包面积做方向无关的安全上界剪枝；再计算最小外接
    矩形面积相对碎片总面积的空隙率。KNOWN可额外提供100×60mm尺寸提示，优先
    搜索外框更接近已知目标的状态；提示只改变顺序，不参与合法性判定。
    返回None表示不可能装入122×92mm目标，否则返回可排序浮点元组。
    """
    polygons = [np.asarray(polygon, dtype=np.float64) for polygon in placed_polygons]
    all_points = np.vstack(polygons)
    maximum_diagonal = math.hypot(
        UNKNOWN_LONG_SIDE_RANGE_MM[1],
        UNKNOWN_SHORT_SIDE_RANGE_MM[1],
    ) + max(0.0, float(tolerance_mm))
    point_differences = all_points[:, None, :] - all_points[None, :, :]
    maximum_distance = float(
        np.sqrt(np.max(np.sum(point_differences * point_differences, axis=2)))
    )
    if maximum_distance > maximum_diagonal:
        return None

    hull = cv2.convexHull(all_points.astype(np.float32).reshape(-1, 1, 2))
    maximum_area = (
        UNKNOWN_LONG_SIDE_RANGE_MM[1] * UNKNOWN_SHORT_SIDE_RANGE_MM[1]
    )
    if abs(float(cv2.contourArea(hull))) > maximum_area * 1.05:
        return None

    rectangle = cv2.minAreaRect(all_points.astype(np.float32).reshape(-1, 1, 2))
    rectangle_sides = sorted(
        (float(rectangle[1][0]), float(rectangle[1][1])),
        reverse=True,
    )
    rectangle_area = max(1.0, rectangle_sides[0] * rectangle_sides[1])
    piece_area = sum(
        abs(float(cv2.contourArea(polygon.astype(np.float32))))
        for polygon in polygons
    )
    gap_ratio = max(0.0, rectangle_area - piece_area) / max(1.0, piece_area)
    hint_error = 0.0
    if target_size_hint_mm is not None:
        hinted_sides = sorted(
            (float(target_size_hint_mm[0]), float(target_size_hint_mm[1])),
            reverse=True,
        )
        if min(hinted_sides) <= 0.0 or not np.all(np.isfinite(hinted_sides)):
            raise ValueError("目标尺寸提示必须包含两个有限正数")
        hint_error = (
            abs(rectangle_sides[0] - hinted_sides[0]) / hinted_sides[0]
            + abs(rectangle_sides[1] - hinted_sides[1]) / hinted_sides[1]
        )
    return float(hint_error), float(gap_ratio), float(rectangle_area)


def _collinear_edge_overlap_length(first_start, first_end, second_start, second_end, tolerance_mm):
    """返回两条近似共线线段的投影重合长度，不共线时返回0。

    该计算只用于候选排序，不决定最终合法性。角度采用约5度上限，法向距离采用
    现场毫米容差，使远距离顶点抖动下的第二条真实接缝仍能被优先发现。
    """
    first_start = np.asarray(first_start, dtype=np.float64)
    first_end = np.asarray(first_end, dtype=np.float64)
    second_start = np.asarray(second_start, dtype=np.float64)
    second_end = np.asarray(second_end, dtype=np.float64)
    first_vector = first_end - first_start
    second_vector = second_end - second_start
    first_length = float(np.linalg.norm(first_vector))
    second_length = float(np.linalg.norm(second_vector))
    if first_length <= 1e-9 or second_length <= 1e-9:
        return 0.0
    cross_value = first_vector[0] * second_vector[1] - first_vector[1] * second_vector[0]
    cross_ratio = abs(float(cross_value)) / (first_length * second_length)
    if cross_ratio > math.sin(math.radians(5.0)):
        return 0.0

    unit = first_vector / first_length
    normal = np.asarray((-unit[1], unit[0]), dtype=np.float64)
    first_distance = abs(float((second_start - first_start) @ normal))
    second_distance = abs(float((second_end - first_start) @ normal))
    if max(first_distance, second_distance) > max(0.0, float(tolerance_mm)):
        return 0.0
    projections = (
        float((second_start - first_start) @ unit),
        float((second_end - first_start) @ unit),
    )
    overlap_start = max(0.0, min(projections))
    overlap_end = min(first_length, max(projections))
    return max(0.0, overlap_end - overlap_start)


def _candidate_contact_length(candidate_polygon, placed_polygons, tolerance_mm=3.0):
    """累计新候选与全部已放置碎片之间的近似共线接触长度。

    正确矩形拼法在搜索后期通常同时接触两片，累计长度明显大于只贴一条边的假解。
    返回值仅作为深度优先顺序，最终仍由尺寸、填充率和重叠率硬验收。
    """
    candidate = np.asarray(candidate_polygon, dtype=np.float64)
    total_length = 0.0
    for placed_polygon in placed_polygons:
        placed = np.asarray(placed_polygon, dtype=np.float64)
        for candidate_edge in range(len(candidate)):
            candidate_start = candidate[candidate_edge]
            candidate_end = candidate[(candidate_edge + 1) % len(candidate)]
            for placed_edge in range(len(placed)):
                total_length += _collinear_edge_overlap_length(
                    candidate_start,
                    candidate_end,
                    placed[placed_edge],
                    placed[(placed_edge + 1) % len(placed)],
                    tolerance_mm,
                )
    return float(total_length)


def _canonicalize_complete_layout(placed_by_index, pixels_per_mm=2.0):
    """把完整组合旋正到长边X轴，并用栅格验证目标矩形尺寸、重叠和缝隙。

    返回值：``(结果, 原因)``；成功时结果为按索引多边形、宽、高和几何分数，
    原因为None；失败时结果为None，原因明确区分尺寸、填充或重叠拒绝。
    """
    indices = sorted(placed_by_index)
    polygons = [np.asarray(placed_by_index[index], dtype=np.float64) for index in indices]
    all_points = np.vstack(polygons).astype(np.float32)
    rectangle = cv2.minAreaRect(all_points.reshape(-1, 1, 2))
    center = np.asarray(rectangle[0], dtype=np.float64)
    angle = math.radians(float(rectangle[2]))
    width_axis = np.asarray((math.cos(angle), math.sin(angle)), dtype=np.float64)
    height_axis = np.asarray((-math.sin(angle), math.cos(angle)), dtype=np.float64)
    canonical = []
    for polygon in polygons:
        relative = polygon - center
        canonical.append(
            np.column_stack((relative @ width_axis, relative @ height_axis))
        )
    combined = np.vstack(canonical)
    span = np.max(combined, axis=0) - np.min(combined, axis=0)
    if span[0] < span[1]:
        # 交换轴并翻转一轴，仍保持行列式为正，避免把实体镜像。
        canonical = [np.column_stack((polygon[:, 1], -polygon[:, 0])) for polygon in canonical]
        combined = np.vstack(canonical)
    minimum = np.min(combined, axis=0)
    canonical = [polygon - minimum for polygon in canonical]
    combined = np.vstack(canonical)
    width_mm, height_mm = np.max(combined, axis=0)
    if not (
        UNKNOWN_LONG_SIDE_RANGE_MM[0] <= width_mm <= UNKNOWN_LONG_SIDE_RANGE_MM[1]
        and UNKNOWN_SHORT_SIDE_RANGE_MM[0] <= height_mm <= UNKNOWN_SHORT_SIDE_RANGE_MM[1]
    ):
        return None, "size_reject"

    masks = _rasterize_polygons(canonical, pixels_per_mm=pixels_per_mm, erode=False)
    union = np.zeros_like(masks[0])
    total_pixels = 0
    for mask in masks:
        total_pixels += int(np.count_nonzero(mask))
        union = cv2.bitwise_or(union, mask)
    union_pixels = max(1, int(np.count_nonzero(union)))
    overlap_ratio = max(0.0, float(total_pixels - union_pixels) / float(union_pixels))

    # 在旋正后的目标外框内统计填充率，黑色缝隙和缺片都会直接降低该值。
    rectangle_pixels = max(
        1.0,
        (width_mm * pixels_per_mm + 1.0) * (height_mm * pixels_per_mm + 1.0),
    )
    fill_ratio = min(1.0, float(union_pixels) / rectangle_pixels)
    if overlap_ratio > UNKNOWN_MAX_OVERLAP_RATIO:
        return None, "overlap_reject"
    if fill_ratio < UNKNOWN_MIN_FILL_RATIO:
        return None, "fill_reject"
    geometry_score = (1.0 - fill_ratio) * 50.0 + overlap_ratio * 50.0
    return (
        (
            {index: polygon for index, polygon in zip(indices, canonical)},
            float(width_mm),
            float(height_mm),
            float(geometry_score),
        ),
        None,
    )


def _coincident_edge(first_polygon, first_edge, second_polygon, second_edge, tolerance_mm=1.0):
    """判断两个目标边是否以反向端点在毫米容差内重合。"""
    first_start = first_polygon[first_edge]
    first_end = first_polygon[(first_edge + 1) % len(first_polygon)]
    second_start = second_polygon[second_edge]
    second_end = second_polygon[(second_edge + 1) % len(second_polygon)]
    return (
        np.linalg.norm(first_start - second_end) <= tolerance_mm
        and np.linalg.norm(first_end - second_start) <= tolerance_mm
    )


def _complete_layout_texture_score(canonical_by_index, solver_pieces):
    """汇总完整布局中所有反向重合内部边的牌面接缝分数。"""
    total_score = 0.0
    seam_count = 0
    indices = sorted(canonical_by_index)
    for first_position, first_index in enumerate(indices):
        first_polygon = canonical_by_index[first_index]
        for second_index in indices[first_position + 1 :]:
            second_polygon = canonical_by_index[second_index]
            for first_edge in range(len(first_polygon)):
                for second_edge in range(len(second_polygon)):
                    if not _coincident_edge(
                        first_polygon,
                        first_edge,
                        second_polygon,
                        second_edge,
                    ):
                        continue
                    total_score += edge_feature_match_score(
                        solver_pieces[first_index]["edge_features"][first_edge],
                        solver_pieces[second_index]["edge_features"][second_edge],
                    )
                    seam_count += 1
    return 0.0 if seam_count == 0 else total_score / seam_count


def _solve_unknown_layout_steps(
    pieces,
    work_region_mm,
    split_y_mm,
    edge_length_tolerance_mm=2.5,
    max_nodes=12000,
    pixels_per_mm=2.0,
    target_size_hint_mm=None,
    texture_refinement_nodes=400,
    progress=None,
):
    """逐工作单元求解1～4片未知多边形，并通过生成器让出主循环。

    主要流程：固定第一片消除整体自由度，枚举未放置边与已放置边的刚体对齐，
    用毫米栅格剪除重叠；完整组合通过尺寸、填充率和重叠率验收，并以牌面接缝
    连续性打破几何同分。每完成一个较重候选检查就yield一次，使调用方可以跨帧
    恢复；生成器结束时通过StopIteration.value返回AssemblyPlan。

    关键参数：texture_refinement_nodes限制找到首个带纹理解后继续比较的节点数；
    progress为可选字典，用于向任务对象实时公开节点数和首解节点。
    """
    pieces = list(pieces)
    if not 1 <= len(pieces) <= 4:
        return AssemblyPlan.failed("unknown_piece_count")
    try:
        max_nodes = int(max_nodes)
        pixels_per_mm = float(pixels_per_mm)
        length_tolerance = float(edge_length_tolerance_mm)
        texture_refinement_nodes = int(texture_refinement_nodes)
        if (
            max_nodes <= 0
            or pixels_per_mm <= 0.0
            or length_tolerance < 0.0
            or texture_refinement_nodes < 0
        ):
            raise ValueError
        solver_pieces = [_solver_piece(piece, index) for index, piece in enumerate(pieces)]
    except (KeyError, TypeError, ValueError):
        return AssemblyPlan.failed("unknown_geometry_invalid")

    # progress由增量任务持有。同步入口不需要进度时仍使用局部字典，保持同一核心。
    progress = progress if isinstance(progress, dict) else {}
    progress["search_nodes"] = 0
    progress["first_solution_node"] = None

    has_pattern = any(
        feature
        and float(feature.get("pattern_energy", 0.0)) >= PATTERN_ENERGY_THRESHOLD
        for solver_piece in solver_pieces
        for feature in solver_piece["edge_features"]
    )
    first_polygon = solver_pieces[0]["local_vertices"].copy()
    best_candidate = None
    best_score = float("inf")
    search_nodes = 0
    first_solution_node = None
    reached_limit = False
    stop_search = False
    segmented_seam_cache = {}
    rejection_counts = {
        "edge_mismatch": 0,
        "size_reject": 0,
        "fill_reject": 0,
        "overlap_reject": 0,
        "complete_candidates": 0,
    }

    def evaluate_complete(placed_by_index):
        """验收完整组合并在分数更低时保存规范化候选。"""
        nonlocal best_candidate, best_score, first_solution_node, stop_search
        rejection_counts["complete_candidates"] += 1
        canonical_result, rejection_reason = _canonicalize_complete_layout(
            placed_by_index,
            pixels_per_mm=pixels_per_mm,
        )
        if canonical_result is None:
            rejection_counts[rejection_reason] += 1
            return
        canonical_by_index, width_mm, height_mm, geometry_score = canonical_result
        texture_score = _complete_layout_texture_score(
            canonical_by_index,
            solver_pieces,
        )
        score = geometry_score + texture_score * 20.0
        if score < best_score:
            best_score = score
            best_candidate = (canonical_by_index, width_mm, height_mm)
            if first_solution_node is None:
                # 首解节点是有限纹理优化窗口的起点，避免已有答案后仍跑满总上限。
                first_solution_node = search_nodes
                progress["first_solution_node"] = int(search_nodes)
            # 白片没有纹理同分问题，首个近乎无缝矩形即可结束以保障实时性。
            if not has_pattern and geometry_score <= UNKNOWN_WHITE_EARLY_STOP_SCORE:
                stop_search = True
            elif has_pattern and texture_refinement_nodes == 0:
                stop_search = True

    def search(placed_by_index, remaining_indices):
        """按紧凑度递归枚举，并在每个高成本候选后yield一个工作单元。"""
        nonlocal search_nodes, reached_limit, stop_search
        if stop_search or reached_limit:
            return
        if not remaining_indices:
            evaluate_complete(placed_by_index)
            # 完整布局的栅格验收和纹理评分也计为一个可让出的高成本工作单元。
            yield None
            return

        expansions = []
        seen_poses = set()
        for source_index in tuple(remaining_indices):
            source_polygon = solver_pieces[source_index]["local_vertices"]
            source_lengths = [
                _edge_length(source_polygon, edge_index)
                for edge_index in range(len(source_polygon))
            ]
            for target_index, target_polygon in tuple(placed_by_index.items()):
                for target_edge in range(len(target_polygon)):
                    target_length = _edge_length(target_polygon, target_edge)
                    for source_edge, source_length in enumerate(source_lengths):
                        tolerance = max(length_tolerance, 0.04 * max(source_length, target_length))
                        lengths_are_equal = abs(source_length - target_length) <= tolerance
                        if not lengths_are_equal:
                            seam_key = (
                                source_index,
                                source_edge,
                                target_index,
                                target_edge,
                            )
                            if seam_key not in segmented_seam_cache:
                                segmented_seam_cache[seam_key] = _segmented_seam_is_possible(
                                    solver_pieces,
                                    source_index,
                                    source_length,
                                    target_index,
                                    target_length,
                                    length_tolerance,
                                )
                            if not segmented_seam_cache[seam_key]:
                                continue
                        candidates = _align_source_edge_candidates(
                            source_polygon,
                            source_edge,
                            target_polygon,
                            target_edge,
                        )
                        for candidate_polygon in candidates:
                            overlaps = _candidate_overlaps(
                                candidate_polygon,
                                list(placed_by_index.values()),
                                pixels_per_mm=pixels_per_mm,
                            )
                            if overlaps:
                                rejection_counts["overlap_reject"] += 1
                                yield None
                                continue
                            # 同一碎片可能通过多组共线边得到完全相同位姿，只保留一次。
                            pose_key = (
                                source_index,
                                tuple(np.rint(candidate_polygon.flatten() * 100.0).astype(int)),
                            )
                            if pose_key in seen_poses:
                                yield None
                                continue
                            seen_poses.add(pose_key)
                            updated = dict(placed_by_index)
                            updated[source_index] = candidate_polygon
                            partial_priority = _partial_layout_priority(
                                list(updated.values()),
                                tolerance_mm=length_tolerance,
                                target_size_hint_mm=target_size_hint_mm,
                            )
                            if partial_priority is None:
                                yield None
                                continue
                            # 先走外接框空隙最小的状态；同分时整边匹配优先于分段匹配。
                            contact_length = _candidate_contact_length(
                                candidate_polygon,
                                list(placed_by_index.values()),
                                tolerance_mm=max(length_tolerance, 3.0),
                            )
                            if target_size_hint_mm is None:
                                priority = (
                                    -contact_length,
                                    partial_priority[1],
                                    0 if lengths_are_equal else 1,
                                    partial_priority[2],
                                )
                            else:
                                priority = (
                                    partial_priority[0],
                                    -contact_length,
                                    partial_priority[1],
                                    0 if lengths_are_equal else 1,
                                    partial_priority[2],
                                )
                            next_remaining = tuple(
                                index for index in remaining_indices if index != source_index
                            )
                            expansions.append((priority, updated, next_remaining))
                            # 重叠、外框和接触边计算是实测热点；完成后立即允许主循环恢复。
                            yield None

        expansions.sort(key=lambda item: item[0])
        for _, updated, next_remaining in expansions:
            search_nodes += 1
            progress["search_nodes"] = int(search_nodes)
            if search_nodes > max_nodes:
                search_nodes = max_nodes
                progress["search_nodes"] = int(search_nodes)
                reached_limit = True
                return
            if (
                first_solution_node is not None
                and search_nodes - first_solution_node >= texture_refinement_nodes
            ):
                # 牌面只在首解附近做有限择优；这条停止条件是实时性的关键保证。
                stop_search = True
                return
            yield from search(updated, next_remaining)
            if stop_search or reached_limit:
                return

    yield from search({0: first_polygon}, tuple(range(1, len(solver_pieces))))
    if best_candidate is None:
        if reached_limit:
            reason = "search_limit"
        elif rejection_counts["complete_candidates"] > 0:
            # 单片无需接缝也会直接进入完整验收；只要存在完整候选，就应报告真实的
            # 尺寸、填充或重叠原因，不能因为search_nodes为0误报EDGE_MISMATCH。
            reason_priority = ("size_reject", "fill_reject", "overlap_reject")
            reason = max(
                reason_priority,
                key=lambda name: (rejection_counts[name], -reason_priority.index(name)),
            )
        elif search_nodes == 0:
            reason = "edge_mismatch"
            rejection_counts["edge_mismatch"] += 1
        else:
            # 有边候选却始终无法放完全部碎片，通常是接缝组合不闭合；若所有扩展
            # 都被实体重叠剪掉，则优先提示重叠，便于现场判断顶点误差。
            reason = (
                "overlap_reject"
                if rejection_counts["overlap_reject"] > 0
                else "edge_mismatch"
            )
            rejection_counts[reason] += 1
        return AssemblyPlan.failed(
            reason,
            search_nodes=search_nodes,
            diagnostics=rejection_counts,
        )

    canonical_by_index, target_width, target_height = best_candidate
    target_rect = _target_rect_in_lower_region(
        work_region_mm,
        split_y_mm,
        (target_width, target_height),
    )
    if target_rect is None:
        return AssemblyPlan.failed("target_out_of_work_region", search_nodes=search_nodes)
    target_origin = np.asarray(target_rect[:2], dtype=np.float64)
    placements = []
    for index, solver_piece in enumerate(solver_pieces):
        target_polygon = canonical_by_index[index] + target_origin
        rotation_delta, _ = _best_rotation_delta_deg(
            solver_piece["source_vertices"],
            target_polygon,
        )
        placements.append(
            AssemblyPlacement(
                solver_piece["id"],
                solver_piece["source_center"],
                _polygon_centroid(target_polygon),
                target_polygon,
                rotation_delta,
            )
        )
    placements.sort(key=lambda placement: placement.piece_id)
    return AssemblyPlan(
        True,
        placements=placements,
        target_rect_mm=target_rect,
        score=best_score,
        reason="ok",
        search_nodes=search_nodes,
    )


class UnknownSolveJob:
    """把未知拼装生成器封装为可在相机多帧之间恢复的增量任务。"""

    def __init__(
        self,
        pieces,
        work_region_mm,
        split_y_mm,
        edge_length_tolerance_mm=2.5,
        max_nodes=12000,
        pixels_per_mm=2.0,
        target_size_hint_mm=None,
        texture_refinement_nodes=400,
        clock=None,
    ):
        """创建尚未执行的求解任务并复制调用参数。

        主要流程：构造共享增量生成器；clock默认使用单调时钟，测试可注入替代时钟。
        输入碎片由求解核心立即转换为列表，主循环后续帧不会改变本任务的集合引用。
        返回值：构造函数无返回值；结果通过advance()、done和result读取。
        """
        self._progress = {"search_nodes": 0, "first_solution_node": None}
        self._clock = clock if clock is not None else time.monotonic
        self._iterator = _solve_unknown_layout_steps(
            pieces,
            work_region_mm,
            split_y_mm,
            edge_length_tolerance_mm=edge_length_tolerance_mm,
            max_nodes=max_nodes,
            pixels_per_mm=pixels_per_mm,
            target_size_hint_mm=target_size_hint_mm,
            texture_refinement_nodes=texture_refinement_nodes,
            progress=self._progress,
        )
        self.done = False
        self.result = None

    @property
    def search_nodes(self):
        """返回任务目前已经深入的搜索节点数，供状态栏显示进度。"""
        return int(self._progress.get("search_nodes", 0))

    @property
    def first_solution_node(self):
        """返回首个合法矩形出现的节点；尚无合法解时返回None。"""
        value = self._progress.get("first_solution_node")
        return None if value is None else int(value)

    def advance(self, time_budget_ms=12.0, work_unit_limit=32):
        """在当前帧预算内推进任务，完成时返回规划，否则返回None。

        关键参数：time_budget_ms限制墙钟时间，work_unit_limit限制生成器让出点数量；
        双限制防止计时精度或某类候选数量异常。为保证任务持续前进，每次调用至少
        执行一个工作单元后才检查时间。任务完成后的重复调用直接返回同一结果。
        """
        if self.done:
            return self.result
        try:
            budget_seconds = float(time_budget_ms) / 1000.0
            unit_limit = int(work_unit_limit)
            if budget_seconds <= 0.0 or unit_limit <= 0:
                raise ValueError
        except (TypeError, ValueError):
            raise ValueError("求解时间预算和工作单元上限必须大于零")

        started_at = float(self._clock())
        processed_units = 0
        while processed_units < unit_limit:
            if processed_units > 0 and float(self._clock()) - started_at >= budget_seconds:
                break
            try:
                next(self._iterator)
            except StopIteration as completed:
                self.result = completed.value
                self.done = True
                return self.result
            processed_units += 1
        return None

    def cancel(self):
        """关闭尚未完成的生成器并返回不含机械目标的取消结果。

        模式切换、进入CAL或运行器重置时调用。已经完成的任务保持原结果；未完成任务
        立即关闭递归生成器，释放其候选列表和栅格引用，后续advance返回同一取消结果。
        """
        if self.done:
            return self.result
        self._iterator.close()
        self.result = AssemblyPlan.failed("cancelled", search_nodes=self.search_nodes)
        self.done = True
        return self.result

    def run_to_completion(self):
        """连续消费增量核心直到结束，供兼容的同步API和PC测试复用。"""
        while not self.done:
            self.advance(time_budget_ms=60000.0, work_unit_limit=1000000)
        return self.result


def solve_unknown_layout(
    pieces,
    work_region_mm,
    split_y_mm,
    edge_length_tolerance_mm=2.5,
    max_nodes=12000,
    pixels_per_mm=2.0,
    target_size_hint_mm=None,
    texture_refinement_nodes=400,
):
    """同步求解未知布局，内部完整消费与主循环相同的增量搜索核心。

    该接口用于既有测试和非实时调用；相机主循环必须直接使用UnknownSolveJob，避免
    在一帧内消费全部搜索。返回值为成功或结构化失败的AssemblyPlan。
    """
    job = UnknownSolveJob(
        pieces,
        work_region_mm,
        split_y_mm,
        edge_length_tolerance_mm=edge_length_tolerance_mm,
        max_nodes=max_nodes,
        pixels_per_mm=pixels_per_mm,
        target_size_hint_mm=target_size_hint_mm,
        texture_refinement_nodes=texture_refinement_nodes,
    )
    return job.run_to_completion()


def _prepare_known_registration(pieces, expected_size_mm):
    """筛选四个上半区碎片并生成不会污染视觉结果的临时求解输入。

    主要流程：复用运行器的可操作碎片定义，校验目标尺寸，为四片浅复制字典分配
    R1～R4临时编号。返回值为``(solver_inputs, expected_size, failure_plan)``；成功时
    failure_plan为None，失败时前两项为None并给出具体KNOWN错误。
    """
    source_pieces = [
        piece
        for piece in pieces
        if piece.get("complete") is True and piece.get("region") == "upper"
    ]
    if len(source_pieces) != 4:
        return None, None, AssemblyPlan.failed("known_needs_four")

    try:
        expected_width, expected_height = (float(value) for value in expected_size_mm)
        if (
            expected_width <= 0.0
            or expected_height <= 0.0
            or not np.all(np.isfinite((expected_width, expected_height)))
        ):
            raise ValueError
        solver_inputs = []
        for index, piece in enumerate(source_pieces, start=1):
            # 当前帧可能没有UNKNOWN编号；浅复制后改临时ID可保留轮廓和边缘特征。
            solver_piece = dict(piece)
            solver_piece["id"] = f"R{index}"
            solver_inputs.append(solver_piece)
    except (TypeError, ValueError):
        return None, None, AssemblyPlan.failed("known_geometry_invalid")
    return solver_inputs, (expected_width, expected_height), None


def _finish_known_registration(
    solver_inputs,
    unknown_plan,
    expected_size_mm,
    work_region_mm,
    split_y_mm,
    max_match_score,
):
    """把未知增量求解结果转换成精确KNOWN模板和可立即绘制的规划。

    关键参数：unknown_plan必须成功并携带目标框；expected_size_mm通常为100×60mm。
    主要流程：按测量目标归一缩放、稳定排序生成K1～K4，再用模板快速规划验证。
    返回值为``(known_plan, templates)``；任何几何或匹配异常返回空模板失败规划。
    """
    if not unknown_plan.success or unknown_plan.target_rect_mm is None:
        return unknown_plan, []

    expected_width, expected_height = expected_size_mm
    try:
        target_x, target_y, measured_width, measured_height = unknown_plan.target_rect_mm
        if measured_width <= 0.0 or measured_height <= 0.0:
            raise ValueError("求解目标尺寸无效")
        placement_by_id = {
            placement.piece_id: placement for placement in unknown_plan.placements
        }
        target_origin = np.asarray((target_x, target_y), dtype=np.float64)
        target_scale = np.asarray(
            (expected_width / measured_width, expected_height / measured_height),
            dtype=np.float64,
        )
        candidates = []
        for solver_piece in solver_inputs:
            placement = placement_by_id[solver_piece["id"]]
            descriptor = build_shape_descriptor(solver_piece)
            normalized_target = (
                np.asarray(placement.target_polygon_mm, dtype=np.float64) - target_origin
            ) * target_scale
            _normalize_vertices(normalized_target)
            candidates.append((descriptor, normalized_target))
        candidates.sort(key=lambda item: _descriptor_sort_key(item[0]))
    except (KeyError, TypeError, ValueError):
        return AssemblyPlan.failed("known_registration_failed"), []

    templates = []
    for index, (descriptor, target_vertices) in enumerate(candidates, start=1):
        templates.append(
            {
                "id": f"K{index}",
                **descriptor,
                "target_vertices_mm": target_vertices.astype(float).tolist(),
                "layout_size_mm": [expected_width, expected_height],
            }
        )

    # 重新规划确保返回目标已经是精确100×60mm且编号为K1～K4，可直接写入运行缓存。
    known_plan = solve_known_layout(
        solver_inputs,
        templates,
        work_region_mm,
        split_y_mm,
        max_match_score=max_match_score,
    )
    if not known_plan.success:
        return AssemblyPlan.failed("known_registration_failed"), []
    return known_plan, templates


class KnownRegistrationJob:
    """跨帧执行KNOWN布局登记，并在完成后提供规划与持久化模板。"""

    def __init__(
        self,
        pieces,
        work_region_mm,
        split_y_mm,
        expected_size_mm=KNOWN_TARGET_SIZE_MM,
        edge_length_tolerance_mm=2.5,
        max_nodes=12000,
        pixels_per_mm=2.0,
        max_match_score=1.2,
        texture_refinement_nodes=400,
        clock=None,
    ):
        """准备KNOWN登记输入并创建内部未知增量任务。

        四片数量或目标尺寸不合法时会立即形成失败结果；合法输入直到advance()才执行
        搜索。模板仅在未知计划和KNOWN快速复核都成功后写入templates属性。
        """
        solver_inputs, expected_size, failure_plan = _prepare_known_registration(
            pieces,
            expected_size_mm,
        )
        self._solver_inputs = solver_inputs
        self._expected_size = expected_size
        self._work_region_mm = work_region_mm
        self._split_y_mm = split_y_mm
        self._max_match_score = float(max_match_score)
        self._unknown_job = None
        self.templates = []
        self.result = failure_plan
        self.done = failure_plan is not None
        if not self.done:
            self._unknown_job = UnknownSolveJob(
                solver_inputs,
                work_region_mm,
                split_y_mm,
                edge_length_tolerance_mm=edge_length_tolerance_mm,
                max_nodes=max_nodes,
                pixels_per_mm=pixels_per_mm,
                target_size_hint_mm=expected_size,
                texture_refinement_nodes=texture_refinement_nodes,
                clock=clock,
            )

    @property
    def search_nodes(self):
        """返回内部未知任务已经深入的节点数，供SAVE状态栏显示。"""
        if self._unknown_job is None:
            return 0 if self.result is None else int(self.result.search_nodes)
        return self._unknown_job.search_nodes

    def advance(self, time_budget_ms=12.0, work_unit_limit=32):
        """推进一个KNOWN SAVE时间片；未完成返回None，完成返回最终KNOWN规划。"""
        if self.done:
            return self.result
        unknown_plan = self._unknown_job.advance(
            time_budget_ms=time_budget_ms,
            work_unit_limit=work_unit_limit,
        )
        if unknown_plan is None:
            return None
        self.result, self.templates = _finish_known_registration(
            self._solver_inputs,
            unknown_plan,
            self._expected_size,
            self._work_region_mm,
            self._split_y_mm,
            self._max_match_score,
        )
        self.done = True
        return self.result

    def cancel(self):
        """取消内部未知搜索并清除尚未持久化的KNOWN模板。"""
        if self.done:
            return self.result
        if self._unknown_job is not None:
            self._unknown_job.cancel()
        self.templates = []
        self.result = AssemblyPlan.failed("cancelled", search_nodes=self.search_nodes)
        self.done = True
        return self.result

    def run_to_completion(self):
        """连续推进直到登记完成，供既有同步SAVE接口保持兼容。"""
        while not self.done:
            self.advance(time_budget_ms=60000.0, work_unit_limit=1000000)
        return self.result, self.templates


def solve_and_register_known_layout(
    pieces,
    work_region_mm,
    split_y_mm,
    expected_size_mm=KNOWN_TARGET_SIZE_MM,
    edge_length_tolerance_mm=2.5,
    max_nodes=12000,
    pixels_per_mm=2.0,
    max_match_score=1.2,
    texture_refinement_nodes=400,
):
    """同步登记KNOWN布局，内部完整消费与主循环相同的增量任务。

    该接口保留给PC工具和兼容测试；相机SAVE必须使用KnownRegistrationJob逐帧推进。
    返回值为``(AssemblyPlan, templates)``，失败时模板为空并保留具体原因。
    """
    job = KnownRegistrationJob(
        pieces,
        work_region_mm,
        split_y_mm,
        expected_size_mm=expected_size_mm,
        edge_length_tolerance_mm=edge_length_tolerance_mm,
        max_nodes=max_nodes,
        pixels_per_mm=pixels_per_mm,
        max_match_score=max_match_score,
        texture_refinement_nodes=texture_refinement_nodes,
    )
    return job.run_to_completion()


def _template_context_fingerprint(templates):
    """生成不抛异常的模板指纹，损坏布局使用稳定哨兵交给规划阶段拒绝。

    指纹只负责判断上下文是否变化，不能在相机主循环前置阶段验证持久模板。无效字段
    会编码为invalid类型键；随后solve_known_layout返回template_layout_invalid。
    """
    fingerprint = []
    for template in templates:
        if not isinstance(template, dict):
            fingerprint.append(("<invalid>", ("invalid_template", type(template).__name__)))
            continue
        target_vertices = template.get("target_vertices_mm")
        if target_vertices is None:
            layout_key = ("none",)
        else:
            try:
                normalized_vertices = tuple(
                    tuple(round(float(value), 3) for value in point)
                    for point in target_vertices
                )
                layout_key = ("valid", normalized_vertices)
            except (TypeError, ValueError):
                layout_key = ("invalid_layout", type(target_vertices).__name__)
        fingerprint.append((str(template.get("id", "")), layout_key))
    return tuple(sorted(fingerprint))


def _piece_observation(piece):
    """提取稳定帧比较所需的顶点数、毫米中心和有序毫米顶点。"""
    vertices = _normalize_vertices(piece["vertices_mm"])
    center = tuple(float(value) for value in piece.get("center_mm", _polygon_centroid(vertices)))
    return {
        "vertex_count": len(vertices),
        "center": np.asarray(center, dtype=np.float64),
        "vertices": vertices,
    }


def _polygon_frame_distance(first_vertices, second_vertices):
    """枚举循环起点和遍历方向，计算两帧同片顶点的最小RMS毫米位移。"""
    if len(first_vertices) != len(second_vertices):
        return float("inf")
    best_distance = float("inf")
    for traversal in (second_vertices, second_vertices[::-1]):
        for shift in range(len(second_vertices)):
            aligned = np.roll(traversal, shift, axis=0)
            distance = float(
                np.sqrt(np.mean(np.sum((first_vertices - aligned) ** 2, axis=1)))
            )
            best_distance = min(best_distance, distance)
    return best_distance


def _observations_are_stable(reference, current, tolerance_mm):
    """对不超过四片的两帧观测穷举一对一对应，判断全部顶点位移是否在容差内。"""
    if len(reference) != len(current):
        return False
    for assignment in itertools.permutations(range(len(current))):
        assignment_valid = True
        for reference_index, current_index in enumerate(assignment):
            first = reference[reference_index]
            second = current[current_index]
            if first["vertex_count"] != second["vertex_count"]:
                assignment_valid = False
                break
            if np.linalg.norm(first["center"] - second["center"]) > tolerance_mm:
                assignment_valid = False
                break
            if _polygon_frame_distance(first["vertices"], second["vertices"]) > tolerance_mm:
                assignment_valid = False
                break
        if assignment_valid:
            return True
    return False


class AssemblyRuntime:
    """维护连续稳定帧门、一次求解和跨帧缓存。

    规划缓存用于机械开始移动后的画面：碎片位置变化不会触发重算；识别模式、模板、
    黄色机械区域或分界线变化会自动建立新上下文并清除旧目标。
    """

    def __init__(
        self,
        stable_frames=3,
        position_tolerance_mm=2.0,
        solver_time_budget_ms=12.0,
        solver_work_unit_limit=32,
        texture_refinement_nodes=400,
    ):
        """初始化稳定门与UNKNOWN单帧求解预算。

        关键参数：solver_time_budget_ms和solver_work_unit_limit共同限制每帧计算量；
        texture_refinement_nodes限制带纹理首解后的附加择优节点。所有参数必须有效。
        返回值：构造函数无返回值，运行状态通过update和公开属性读取。
        """
        self.stable_frames = int(stable_frames)
        self.position_tolerance_mm = float(position_tolerance_mm)
        self.solver_time_budget_ms = float(solver_time_budget_ms)
        self.solver_work_unit_limit = int(solver_work_unit_limit)
        self.texture_refinement_nodes = int(texture_refinement_nodes)
        if (
            self.stable_frames <= 0
            or self.position_tolerance_mm <= 0.0
            or self.solver_time_budget_ms <= 0.0
            or self.solver_work_unit_limit <= 0
            or self.texture_refinement_nodes < 0
        ):
            raise ValueError("稳定门、单帧预算和纹理优化节点参数无效")
        self.solve_count = 0
        self._context_key = None
        self._reference_observation = None
        self._solve_job = None
        self.stable_count = 0
        self.plan = None

    @property
    def is_solving(self):
        """返回当前是否存在尚未完成的UNKNOWN增量求解任务。"""
        return self._solve_job is not None and not self._solve_job.done

    @property
    def search_nodes(self):
        """返回当前增量任务或已缓存规划的节点数，供状态栏显示。"""
        if self._solve_job is not None:
            return self._solve_job.search_nodes
        if self.plan is not None:
            return int(self.plan.search_nodes)
        return 0

    def reset(self):
        """清除上下文、未完成任务和规划缓存，但保留生命周期求解计数。"""
        if self._solve_job is not None:
            self._solve_job.cancel()
        self._context_key = None
        self._reference_observation = None
        self._solve_job = None
        self.stable_count = 0
        self.plan = None

    def _reset_tracking(self):
        """上下文变化时清除帧跟踪、未完成任务和目标，再从当前帧累计。"""
        if self._solve_job is not None:
            self._solve_job.cancel()
        self._reference_observation = None
        self._solve_job = None
        self.stable_count = 0
        self.plan = None

    def _build_context_key(self, mode, templates, work_region_mm, split_y_mm):
        """校验规划上下文并生成决定缓存是否仍可复用的稳定键。

        关键参数包括模式、模板目标轮廓、黄色机械区域和红色分界线；任一项变化都
        必须使旧机械目标失效。返回值同时包含规范后的模式、区域、分界线和键。
        """
        normalized_mode = str(mode).lower()
        if normalized_mode not in ("known", "unknown"):
            raise ValueError("规划模式必须是known或unknown")
        work_region = validate_work_region_mm(work_region_mm)
        split_y = validate_split_y_mm(work_region, split_y_mm)
        template_key = (
            _template_context_fingerprint(templates)
            if normalized_mode == "known"
            else ()
        )
        context_key = (
            normalized_mode,
            tuple(round(float(value), 3) for value in work_region),
            round(split_y, 3),
            template_key,
        )
        return normalized_mode, work_region, split_y, context_key

    def cache_plan(self, mode, plan, templates, work_region_mm, split_y_mm):
        """预装一次已经验收成功的规划，供SAVE后立即显示并跨帧复用。

        主要流程：使用与update完全相同的上下文键绑定规划，把稳定计数置为已满足；
        只接受成功且含目标的AssemblyPlan，避免失败结果被误当成机械缓存。
        返回值：输入plan本身，便于调用方直接用于当前帧绘制。
        """
        if not isinstance(plan, AssemblyPlan) or not plan.success:
            raise ValueError("只能缓存成功的AssemblyPlan")
        _, _, _, context_key = self._build_context_key(
            mode,
            templates,
            work_region_mm,
            split_y_mm,
        )
        if self._solve_job is not None:
            self._solve_job.cancel()
        self._context_key = context_key
        self._reference_observation = None
        self._solve_job = None
        self.stable_count = self.stable_frames
        self.plan = plan
        return plan

    def _advance_unknown_job(self):
        """推进当前UNKNOWN任务，并把不可恢复异常转换成安全失败规划。

        主要流程：按构造时预算调用advance；异常时读取已有节点数形成solver_error，
        显式取消任务释放生成器；成功或失败结果均写入plan并清除任务引用。
        返回值：未完成为None，结束后为AssemblyPlan。
        """
        try:
            result = self._solve_job.advance(
                time_budget_ms=self.solver_time_budget_ms,
                work_unit_limit=self.solver_work_unit_limit,
            )
        except Exception:
            search_nodes = int(getattr(self._solve_job, "search_nodes", 0))
            try:
                self._solve_job.cancel()
            except Exception:
                # 异常清理不能覆盖原始求解失败；丢弃引用后由Python回收对象。
                pass
            result = AssemblyPlan.failed("solver_error", search_nodes=search_nodes)
        if result is not None:
            self.plan = result
            self._solve_job = None
        return self.plan

    def update(
        self,
        mode,
        pieces,
        templates,
        work_region_mm,
        split_y_mm,
        known_match_threshold=1.2,
        unknown_max_nodes=12000,
    ):
        """接收一帧识别数据，在稳定门满足后求解一次并返回缓存。

        关键参数：mode为known或unknown；只使用complete且region=upper的1～4片。
        UNKNOWN达到稳定门后只创建并推进一个短时间片；任务执行期间返回None，完成后
        返回成功或失败AssemblyPlan。KNOWN模板匹配规模固定且很小，继续同步完成。
        """
        mode, work_region, split_y, context_key = self._build_context_key(
            mode,
            templates,
            work_region_mm,
            split_y_mm,
        )
        if context_key != self._context_key:
            self._context_key = context_key
            self._reset_tracking()
        if self.plan is not None:
            return self.plan
        if self._solve_job is not None:
            # 已启动任务使用第3稳定帧的几何快照；后续帧只推进任务，不因识别抖动重启。
            return self._advance_unknown_job()

        actionable = [
            piece
            for piece in pieces
            if piece.get("complete") is True and piece.get("region") == "upper"
        ]
        if not 1 <= len(actionable) <= 4:
            self._reference_observation = None
            self.stable_count = 0
            return None
        try:
            current_observation = [_piece_observation(piece) for piece in actionable]
        except (KeyError, TypeError, ValueError):
            self._reference_observation = None
            self.stable_count = 0
            return None

        if self._reference_observation is None:
            self.stable_count = 1
        elif _observations_are_stable(
            self._reference_observation,
            current_observation,
            self.position_tolerance_mm,
        ):
            self.stable_count += 1
        else:
            self.stable_count = 1
        self._reference_observation = current_observation
        if self.stable_count < self.stable_frames:
            return None

        self.solve_count += 1
        if mode == "known":
            self.plan = solve_known_layout(
                actionable,
                templates,
                work_region,
                split_y,
                max_match_score=known_match_threshold,
            )
        else:
            self._solve_job = UnknownSolveJob(
                actionable,
                work_region,
                split_y,
                max_nodes=unknown_max_nodes,
                texture_refinement_nodes=self.texture_refinement_nodes,
            )
            self.plan = self._advance_unknown_job()
        return self.plan


COLOR_PLAN_SPLIT = (0, 0, 255)
COLOR_PLAN_TARGET = (255, 0, 255)
COLOR_PLAN_ARROW = (0, 165, 255)
COLOR_PLAN_PIECES = (
    (0, 255, 0),
    (255, 180, 0),
    (0, 220, 220),
    (220, 100, 255),
)


def _rect_corners(rect_mm):
    """把X/Y/W/H目标矩形转换为顺时针四个毫米角点。"""
    rect_x, rect_y, rect_width, rect_height = (float(value) for value in rect_mm)
    return np.asarray(
        (
            (rect_x, rect_y),
            (rect_x + rect_width, rect_y),
            (rect_x + rect_width, rect_y + rect_height),
            (rect_x, rect_y + rect_height),
        ),
        dtype=np.float32,
    )


def draw_assembly_plan(frame_bgr, plan, paper_quad, work_region_mm, split_y_mm):
    """在相机画面副本上绘制毫米分界线、目标矩形、单片轮廓、箭头和位姿文字。

    失败或尚未求解时仍绘制红色分界线；只有成功plan才输出机械目标。所有毫米点
    通过完整A4单应性映射，输入frame_bgr保持不变。返回值：同尺寸BGR新图像。
    """
    if frame_bgr is None or not isinstance(frame_bgr, np.ndarray):
        raise ValueError("frame_bgr必须是有效numpy图像")
    output = frame_bgr.copy()
    split_segment = build_split_segment(paper_quad, work_region_mm, split_y_mm)
    cv2.line(
        output,
        tuple(np.rint(split_segment[0]).astype(np.int32)),
        tuple(np.rint(split_segment[1]).astype(np.int32)),
        COLOR_PLAN_SPLIT,
        2,
    )
    if plan is None or not plan.success or plan.target_rect_mm is None:
        return output

    target_rect_px = paper_points_to_image_px(
        _rect_corners(plan.target_rect_mm),
        paper_quad,
    )
    for index, placement in enumerate(plan.placements):
        color = COLOR_PLAN_PIECES[index % len(COLOR_PLAN_PIECES)]
        target_polygon_px = paper_points_to_image_px(
            placement.target_polygon_mm,
            paper_quad,
        )
        source_center_px = paper_points_to_image_px(
            [placement.source_center_mm],
            paper_quad,
        )[0]
        target_center_px = paper_points_to_image_px(
            [placement.target_center_mm],
            paper_quad,
        )[0]
        target_polygon_int = np.rint(target_polygon_px).astype(np.int32)
        source_center_int = tuple(np.rint(source_center_px).astype(np.int32))
        target_center_int = tuple(np.rint(target_center_px).astype(np.int32))
        cv2.polylines(output, [target_polygon_int], True, color, 2)
        cv2.arrowedLine(
            output,
            source_center_int,
            target_center_int,
            COLOR_PLAN_ARROW,
            2,
            tipLength=0.12,
        )
        label = (
            f"{placement.piece_id} "
            f"({placement.target_center_mm[0]:.1f},{placement.target_center_mm[1]:.1f}) "
            f"R{placement.rotation_delta_deg:+.1f}"
        )
        cv2.putText(
            output,
            label,
            (max(0, target_center_int[0] + 4), max(14, target_center_int[1] - 4)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.38,
            color,
            1,
            cv2.LINE_AA,
        )
    # 总目标外框最后绘制，避免单片轮廓与外框重合时把矩形边界完全覆盖。
    cv2.polylines(
        output,
        [np.rint(target_rect_px).astype(np.int32)],
        True,
        COLOR_PLAN_TARGET,
        2,
    )
    return output
