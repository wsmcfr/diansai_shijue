"""MaixCAM2 拼图碎片识别应用入口。"""

import os
import sys

import cv2
import numpy as np

# MaixVision直接运行本文件时补入项目父目录；作为maixcam2_app包导入时不改变搜索路径。
if __package__ in (None, ""):
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

try:
    from maixcam2_app_A_quad.assembly_planner import (
        AssemblyRuntime,
        KnownRegistrationJob,
        classify_piece_region,
        draw_assembly_plan,
        solve_and_register_known_layout,
    )
    from maixcam2_app_A_quad.calibration_ui import (
        CalibrationSession,
        draw_calibration_frame,
        evaluate_calibration,
    )
    from maixcam2_app_A_quad.config import (
        DEFAULT_CONFIG,
        PERSISTENT_SETTINGS_PATH,
        PERSISTENT_TEMPLATE_PATH,
    )
    from maixcam2_app_A_quad.paper_locator import (
        build_work_quad,
        image_point_to_paper_mm,
        image_points_to_paper_mm,
        locate_black_paper,
    )
    from maixcam2_app_A_quad.puzzle_vision import (
        DetectionResult,
        assign_unknown_ids,
        detect_pieces,
        sample_piece_edge_features,
    )
    from maixcam2_app_A_quad.settings_store import (
        build_default_runtime_settings,
        load_runtime_settings,
        merge_paper_settings,
        merge_runtime_config,
        merge_segmentation_settings,
        save_runtime_settings,
    )
    from maixcam2_app_A_quad.template_store import (
        load_templates,
        match_known_pieces,
        save_templates,
    )
    from maixcam2_app_A_quad.touch_ui import (
        TouchReleaseTracker,
        build_button_layout,
        build_calibration_layout,
        hit_test,
        map_display_to_image,
    )
except ModuleNotFoundError as error:
    # MaixVision会把工程文件平铺到/tmp/maixpy_run，此时顶层包不存在，
    # 需要从main.py同级位置加载模块；其他模块内部缺失仍应原样抛出，避免掩盖真实依赖错误。
    if error.name != "maixcam2_app_A_quad":
        raise
    from assembly_planner import (
        AssemblyRuntime,
        KnownRegistrationJob,
        classify_piece_region,
        draw_assembly_plan,
        solve_and_register_known_layout,
    )
    from calibration_ui import (
        CalibrationSession,
        draw_calibration_frame,
        evaluate_calibration,
    )
    from config import DEFAULT_CONFIG, PERSISTENT_SETTINGS_PATH, PERSISTENT_TEMPLATE_PATH
    from paper_locator import (
        build_work_quad,
        image_point_to_paper_mm,
        image_points_to_paper_mm,
        locate_black_paper,
    )
    from puzzle_vision import (
        DetectionResult,
        assign_unknown_ids,
        detect_pieces,
        sample_piece_edge_features,
    )
    from settings_store import (
        build_default_runtime_settings,
        load_runtime_settings,
        merge_paper_settings,
        merge_runtime_config,
        merge_segmentation_settings,
        save_runtime_settings,
    )
    from template_store import (
        load_templates,
        match_known_pieces,
        save_templates,
    )
    from touch_ui import (
        TouchReleaseTracker,
        build_button_layout,
        build_calibration_layout,
        hit_test,
        map_display_to_image,
    )


# 模式使用稳定字符串，既用于逻辑判断，也用于屏幕状态栏显示。
MODE_KNOWN = "known"
MODE_UNKNOWN = "unknown"


class QuadFrameAnalysis:
    """保存A版单帧分析的检测结果、有效四边形和实际检测ROI。"""

    def __init__(self, detection, active_quad, roi):
        """初始化纯数据结果，供设备主循环、PC回归和A/B对比工具共同使用。"""
        self.detection = detection
        self.active_quad = active_quad
        self.roi = tuple(int(value) for value in roi)


def build_runtime_active_quad(settings):
    """从已锁定纸张参数派生A版机械有效四边形。

    主要流程：没有 ``paper_quad`` 时返回 None 触发兼容矩形回退；存在四角时根据
    ``inset_mm`` 调用统一物理映射。返回值：None或4×2 float32四角。
    """
    paper_quad = settings.get("paper_quad")
    if paper_quad is None:
        return None
    work_region = (
        settings["work_x_mm"],
        settings["work_y_mm"],
        settings["work_width_mm"],
        settings["work_height_mm"],
    )
    return build_work_quad(paper_quad, work_region)


def _quad_bounding_roi(active_quad, frame_size):
    """计算完整包含浮点四角且限制在相机画面内的整数外接ROI。"""
    frame_width, frame_height = (int(value) for value in frame_size)
    min_x = max(0, int(np.floor(np.min(active_quad[:, 0]))))
    min_y = max(0, int(np.floor(np.min(active_quad[:, 1]))))
    max_x = min(frame_width - 1, int(np.ceil(np.max(active_quad[:, 0]))))
    max_y = min(frame_height - 1, int(np.ceil(np.max(active_quad[:, 1]))))
    if max_x < min_x or max_y < min_y:
        raise ValueError("active_quad 无法生成有效外接ROI")
    return min_x, min_y, max_x - min_x + 1, max_y - min_y + 1


def analyze_quad_frame(frame_bgr, runtime_settings, config=None):
    """执行A版四边形掩膜单帧识别并补充完整A4毫米中心。

    主要流程：从设置派生有效四边形和外接ROI，合并现场分割参数，调用视觉核心；
    锁定纸张时再把每片相机中心反算为A4毫米坐标。
    返回值：``QuadFrameAnalysis``；输入或单应性异常由调用方捕获并显示。
    """
    if frame_bgr is None or not isinstance(frame_bgr, np.ndarray):
        raise ValueError("frame_bgr 必须是有效的 numpy 图像")
    frame_height, frame_width = frame_bgr.shape[:2]
    active_quad = build_runtime_active_quad(runtime_settings)
    if active_quad is None:
        roi = tuple(int(value) for value in runtime_settings["roi"])
    else:
        roi = _quad_bounding_roi(active_quad, (frame_width, frame_height))

    base_config = DEFAULT_CONFIG if config is None else config
    detection_config = merge_runtime_config(base_config, runtime_settings)
    detection = detect_pieces(
        frame_bgr,
        roi,
        detection_config,
        active_quad=active_quad,
    )

    paper_quad = runtime_settings.get("paper_quad")
    if paper_quad is not None:
        for piece in detection.pieces:
            # A版保留相机坐标供画面叠加，同时批量增加毫米多边形供规划器使用。
            piece["center_mm"] = image_point_to_paper_mm(piece["center"], paper_quad)
            vertices_mm = image_points_to_paper_mm(piece["vertices"], paper_quad)
            piece["vertices_mm"] = vertices_mm.astype(float).tolist()
            piece["region"] = classify_piece_region(
                vertices_mm,
                runtime_settings["split_y_mm"],
            )
            piece["edge_features"] = sample_piece_edge_features(
                frame_bgr,
                piece["vertices"],
            )
    return QuadFrameAnalysis(detection, active_quad, roi)


def register_and_save_known_layout(
    pieces,
    template_path,
    work_region_mm,
    split_y_mm,
    max_nodes=12000,
):
    """从上半区随机四片自动求解KNOWN布局并原子保存模板。

    主要流程：调用统一几何求解器得到精确100×60mm模板和即时机械规划；只有规划
    成功时才写模板文件，失败会保留磁盘上的旧模板。关键参数work_region_mm与
    split_y_mm决定下半区是否容得下目标。返回值：``(plan, templates)``。
    """
    plan, templates = solve_and_register_known_layout(
        pieces,
        work_region_mm,
        split_y_mm,
        max_nodes=max_nodes,
    )
    if plan.success:
        save_templates(template_path, templates)
    return plan, templates


def perform_known_save_action(
    pieces,
    current_templates,
    template_path,
    work_region_mm,
    split_y_mm,
    planner_runtime,
    max_nodes=12000,
):
    """执行一次KNOWN触摸保存，并保持内存、磁盘和规划缓存一致。

    主要流程：自动求解并保存上半区四片；失败时返回原模板和具体SAVE原因；成功时
    把新规划绑定到当前运行上下文，使本帧及后续帧立即绘制目标。文件系统异常会
    转换为现场可见状态，避免设备主循环退出。返回值为``(模板, plan, 状态文字)``。
    """
    try:
        plan, new_templates = register_and_save_known_layout(
            pieces,
            template_path,
            work_region_mm,
            split_y_mm,
            max_nodes=max_nodes,
        )
    except Exception as error:
        # 写文件失败时register_and_save_known_layout不会返回，内存继续使用旧模板。
        return current_templates, None, f"SAVE ERROR {type(error).__name__}"
    if not plan.success:
        return current_templates, plan, f"SAVE {plan.reason.upper()}"

    planner_runtime.cache_plan(
        MODE_KNOWN,
        plan,
        new_templates,
        work_region_mm,
        split_y_mm,
    )
    return new_templates, plan, "KNOWN SAVED PLAN OK"


class KnownSaveController:
    """管理KNOWN触摸SAVE的跨帧登记、持久化和规划缓存。"""

    def __init__(
        self,
        time_budget_ms=12.0,
        work_unit_limit=32,
        max_nodes=12000,
        texture_refinement_nodes=400,
    ):
        """初始化每帧预算和总搜索参数，尚未持有SAVE任务。

        关键参数：time_budget_ms与work_unit_limit限制单帧工作量，max_nodes限制无解
        总搜索量，texture_refinement_nodes限制首解后的牌面择优量。参数非法会抛出
        ValueError；结果通过start()、advance()和active属性访问。
        """
        self.time_budget_ms = float(time_budget_ms)
        self.work_unit_limit = int(work_unit_limit)
        self.max_nodes = int(max_nodes)
        self.texture_refinement_nodes = int(texture_refinement_nodes)
        if (
            self.time_budget_ms <= 0.0
            or self.work_unit_limit <= 0
            or self.max_nodes <= 0
            or self.texture_refinement_nodes < 0
        ):
            raise ValueError("KNOWN SAVE求解预算参数无效")
        self._job = None
        self._work_region_mm = None
        self._split_y_mm = None

    @property
    def active(self):
        """返回是否存在尚未结束的KNOWN登记任务。"""
        return self._job is not None and not self._job.done

    @property
    def search_nodes(self):
        """返回当前SAVE任务节点数；空闲时返回0。"""
        return 0 if self._job is None else int(self._job.search_nodes)

    def cancel(self):
        """取消未完成任务并清除绑定的机械上下文，不修改已有模板文件。"""
        if self._job is not None and not self._job.done:
            try:
                self._job.cancel()
            except Exception:
                # 取消用于释放资源，清理异常不能阻止模式切换或CAL界面响应。
                pass
        self._job = None
        self._work_region_mm = None
        self._split_y_mm = None

    def start(self, pieces, work_region_mm, split_y_mm):
        """从当前四片快照启动KNOWN登记，按钮回调中不执行完整搜索。

        已有任务执行时返回SAVE BUSY；输入数量或几何立即不合法时返回具体SAVE失败
        且不保持活动任务。成功启动返回含0节点的SOLVING状态，后续由advance推进。
        """
        if self.active:
            return "SAVE BUSY"
        try:
            self._job = KnownRegistrationJob(
                pieces,
                work_region_mm,
                split_y_mm,
                max_nodes=self.max_nodes,
                texture_refinement_nodes=self.texture_refinement_nodes,
            )
            self._work_region_mm = tuple(float(value) for value in work_region_mm)
            self._split_y_mm = float(split_y_mm)
        except Exception as error:
            self.cancel()
            return f"SAVE ERROR {type(error).__name__}"
        if self._job.done:
            status = f"SAVE {self._job.result.reason.upper()}"
            self.cancel()
            return status
        return "SAVE SOLVING N=0"

    def advance(self, current_templates, template_path, planner_runtime):
        """推进一个SAVE时间片，成功后才保存模板并写入即时规划缓存。

        返回值：``(templates, plan, status)``。未完成和写文件失败均保留调用方传入的
        current_templates；未完成plan为None，求解失败plan为结构化失败结果。
        """
        if not self.active:
            return current_templates, None, "SAVE IDLE"
        try:
            plan = self._job.advance(
                time_budget_ms=self.time_budget_ms,
                work_unit_limit=self.work_unit_limit,
            )
        except Exception as error:
            self.cancel()
            return current_templates, None, f"SAVE ERROR {type(error).__name__}"
        if plan is None:
            return current_templates, None, f"SAVE SOLVING N={self.search_nodes}"

        new_templates = self._job.templates
        work_region_mm = self._work_region_mm
        split_y_mm = self._split_y_mm
        if not plan.success:
            status = f"SAVE {plan.reason.upper()}"
            self.cancel()
            return current_templates, plan, status
        try:
            # 先校验并预装缓存，缓存失败时磁盘旧模板尚未被原子替换。
            planner_runtime.cache_plan(
                MODE_KNOWN,
                plan,
                new_templates,
                work_region_mm,
                split_y_mm,
            )
            # 写盘失败会在异常分支清掉预装缓存，使内存继续沿用调用方的旧模板。
            save_templates(template_path, new_templates)
        except Exception as error:
            try:
                planner_runtime.reset()
            except Exception:
                # 错误状态必须优先返回；清缓存异常不能再次穿透相机主循环。
                pass
            self.cancel()
            return current_templates, None, f"SAVE ERROR {type(error).__name__}"
        self.cancel()
        return new_templates, plan, "KNOWN SAVED PLAN OK"


def match_known_pieces_safely(pieces, templates, max_score):
    """执行KNOWN形状匹配并把损坏模板异常转换成可见状态。

    成功返回原模板和None；异常时把当前碎片全部恢复为UNKNOWN，返回空内存模板和
    `TEMPLATE ERROR 类型`。磁盘文件不在此处修改，用户可重新SAVE覆盖。
    """
    try:
        match_known_pieces(pieces, templates, float(max_score))
    except Exception as error:
        for piece in pieces:
            piece["id"] = "UNKNOWN"
            piece["match_score"] = float("inf")
        return [], f"TEMPLATE ERROR {type(error).__name__}"
    return templates, None


def select_known_template_status(templates, current_status, save_active=False):
    """在KNOWN无模板提示与SAVE状态之间选择优先级更高的文字。

    SAVE进行中、成功、失败或文件错误都必须保留，便于现场判断按钮结果；只有确实
    没有模板且当前没有SAVE相关状态时才返回NO TEMPLATE。已有模板时原样返回状态。
    """
    status = str(current_status)
    if templates or save_active or status.startswith("SAVE") or status.startswith("KNOWN SAVED"):
        return status
    if status.startswith("TEMPLATE ERROR"):
        return status
    return "NO TEMPLATE"


def select_planning_status(
    current_status,
    assembly_plan,
    stable_count,
    stable_frames,
    preserve_current=False,
    solving=False,
    search_nodes=0,
):
    """按动作优先级选择正常界面状态文字。

    SAVE或模式切换发生的当前帧可设置preserve_current，阻止后续规划更新覆盖关键
    操作结果；普通帧依次显示增量求解进度、稳定计数、成功目标数量或具体失败原因。
    solving为True时search_nodes用于现场确认任务仍在推进。返回字符串。
    """
    if preserve_current:
        return str(current_status)
    if str(current_status).startswith("SAVE ") and (
        assembly_plan is None or not assembly_plan.success
    ):
        # SAVE失败必须持续到用户切换模式、重新SAVE或产生成功规划，避免一闪而过。
        return str(current_status)
    if solving:
        return f"SOLVING N={int(search_nodes)}"
    if assembly_plan is None:
        if int(stable_count) > 0:
            return f"STABLE {int(stable_count)}/{int(stable_frames)}"
        return str(current_status)
    if assembly_plan.success:
        return f"PLAN OK N={len(assembly_plan.placements)}"
    return f"PLAN {assembly_plan.reason.upper()}"


class InterfaceState:
    """维护正常/调参界面切换和当前未保存调参会话。

    该结构故意不保存KNOWN/UNKNOWN识别模式，因此同一个CAL按钮往返切换时不会
    意外改变碎片识别模式。
    """

    def __init__(self):
        """初始化为正常识别界面，当前没有未保存调参会话。"""
        self.calibration_session = None

    @property
    def is_calibrating(self):
        """返回当前是否处于调参界面。"""
        return self.calibration_session is not None

    def toggle_calibration(self, saved_settings, frame_size):
        """使用同一个CAL动作进入或退出调参界面。

        主要流程：正常界面时复制已保存参数并创建会话；调参界面时直接丢弃会话，
        因而未保存修改不会污染运行参数。
        关键参数：saved_settings 为当前生效参数，frame_size 为相机 ``(宽, 高)``。
        返回值：切换后处于调参界面返回 True，返回正常界面时返回 False。
        """
        if self.calibration_session is None:
            self.calibration_session = CalibrationSession(saved_settings, frame_size)
            return True
        self.calibration_session = None
        return False


def handle_calibration_action(
    action,
    interface_state,
    runtime_settings,
    detection,
    settings_path,
    frame_size,
    frame_bgr=None,
):
    """处理五页调参动作并执行两组互不覆盖的持久化。

    主要流程：顶部动作切换页面；底部固定槽先由会话映射为AUTO ROI、INSET、LOCK
    或ADV参数动作。LOCK只合并纸张字段，ADV SAVE只合并分割字段。
    frame_bgr 仅在AUTO ROI单次点击时使用。返回值为 ``(运行参数, 状态文字)``。
    """
    if not interface_state.is_calibrating:
        raise ValueError("只有调参界面可以处理调参动作")

    session = interface_state.calibration_session
    action = str(action)
    if action in ("roi", "mask", "result", "adv"):
        session.select_view(action)
        return runtime_settings, action.upper()
    logical_action = session.resolve_control_action(action)
    if logical_action == "auto_roi":
        if frame_bgr is None:
            raise ValueError("AUTO ROI需要当前相机帧")
        location = locate_black_paper(frame_bgr)
        session.apply_auto_roi(location)
        return runtime_settings, session.status_text
    if logical_action == "work_dec":
        session.adjust_work(-1)
        return runtime_settings, session.status_text
    if logical_action == "work_inc":
        session.adjust_work(1)
        return runtime_settings, session.status_text
    if logical_action == "work_value":
        return runtime_settings, f"WORK {session.cycle_work_item()}"
    if logical_action == "lock_roi":
        if not session.can_lock_roi(detection):
            return runtime_settings, session.status_text
        paper_settings = merge_paper_settings(runtime_settings, session.snapshot())
        saved_settings = save_runtime_settings(
            settings_path,
            paper_settings,
            frame_size,
        )
        session.status_text = "ROI LOCKED"
        return saved_settings, session.status_text
    if logical_action == "next_param":
        return runtime_settings, f"PARAM {session.cycle_item()}"
    if logical_action == "value_dec":
        changed = session.adjust(-1)
        return runtime_settings, "ADJUSTED" if changed else "LIMIT"
    if logical_action == "value_inc":
        changed = session.adjust(1)
        return runtime_settings, "ADJUSTED" if changed else "LIMIT"
    if logical_action == "select_value":
        if session.current_item != "TH":
            return runtime_settings, f"PARAM {session.current_item}"
        session.toggle_threshold_mode(detection.threshold)
        return runtime_settings, "TH MODE"
    if logical_action == "save_segmentation":
        if not session.can_save_segmentation(detection):
            return runtime_settings, session.status_text
        segmentation_settings = merge_segmentation_settings(
            runtime_settings,
            session.snapshot(),
        )
        saved_settings = save_runtime_settings(
            settings_path,
            segmentation_settings,
            frame_size,
        )
        session.status_text = "ADV SAVED"
        return saved_settings, session.status_text
    raise ValueError(f"未知调参动作: {action}")


def format_status_text(mode, pieces, threshold, status_message):
    """生成区分有效碎片与边界轮廓的ASCII状态栏文本。

    主要流程：统计 complete 为真的可操作碎片和其余 EDGE 轮廓，再拼接模式、阈值和状态。
    关键参数：pieces 可包含完整及不完整轮廓，threshold 为当前分割阈值。
    返回值：适合 OpenCV 默认字体绘制的单行字符串。
    """
    actionable_count = sum(1 for piece in pieces if piece.get("complete") is True)
    edge_count = len(pieces) - actionable_count
    return (
        f"{mode.upper()} N={actionable_count} EDGE={edge_count} "
        f"TH={threshold:.0f} {status_message}"
    ).strip()


def draw_overlay(
    frame_bgr,
    pieces,
    roi,
    buttons,
    mode,
    threshold,
    status_message,
    paper_quad=None,
    active_quad=None,
    work_region_mm=None,
    split_y_mm=None,
    assembly_plan=None,
):
    """在相机帧副本上绘制工作区、碎片几何信息、模式按钮和状态栏。

    主要流程：复制输入帧，画 ROI 和每片轮廓/顶点/中心，再绘制顶部模式按钮与底部状态。
    关键参数：pieces 为视觉核心输出，buttons 使用图像坐标，mode 为 known 或 unknown。
    返回值：带调试叠加的 BGR 新图像；原始 frame_bgr 保持不变。
    """
    output = frame_bgr.copy()
    frame_height, frame_width = output.shape[:2]
    scale = max(0.45, min(0.75, frame_width / 900.0))
    text_thickness = 1 if frame_width < 960 else 2

    roi_x, roi_y, roi_width, roi_height = roi
    if paper_quad is None:
        # 尚未锁定完整A4时保留稳定版矩形ROI，便于用户仍能进入CAL进行首次标定。
        cv2.rectangle(
            output,
            (roi_x, roi_y),
            (roi_x + roi_width - 1, roi_y + roi_height - 1),
            (255, 200, 0),
            1,
        )
    else:
        cv2.polylines(
            output,
            [np.rint(np.asarray(paper_quad)).astype(np.int32)],
            True,
            (255, 255, 0),
            2,
        )
    if active_quad is not None:
        cv2.polylines(
            output,
            [np.rint(np.asarray(active_quad)).astype(np.int32)],
            True,
            (0, 255, 255),
            2,
        )
    if (
        paper_quad is not None
        and work_region_mm is not None
        and split_y_mm is not None
    ):
        output = draw_assembly_plan(
            output,
            assembly_plan,
            paper_quad,
            work_region_mm,
            split_y_mm,
        )

    for piece in pieces:
        # 完整轮廓使用绿色，不完整轮廓使用橙色，防止边界截断结果被误用于机械控制。
        contour_color = (0, 210, 0) if piece.get("complete", False) else (0, 140, 255)
        cv2.drawContours(output, [piece["contour"]], -1, contour_color, 2)

        for vertex in piece.get("vertices", []):
            cv2.circle(output, tuple(int(value) for value in vertex), 4, (0, 0, 255), -1)

        center_x = int(round(piece["center"][0]))
        center_y = int(round(piece["center"][1]))
        cv2.drawMarker(
            output,
            (center_x, center_y),
            (0, 255, 255),
            cv2.MARKER_CROSS,
            14,
            2,
        )
        label = f'{piece.get("id", "?")} V{len(piece.get("vertices", []))} {piece.get("angle_deg", 0.0):.1f}deg'
        cv2.putText(
            output,
            label,
            (max(0, center_x + 6), max(16, center_y - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            scale,
            (0, 255, 255),
            text_thickness,
            cv2.LINE_AA,
        )

    for name, button in buttons.items():
        x1 = int(round(button.x))
        y1 = int(round(button.y))
        x2 = int(round(button.x + button.width))
        y2 = int(round(button.y + button.height))
        active = name == mode
        enabled = name != "save" or mode == MODE_KNOWN
        if active:
            fill_color = (32, 150, 48)
        elif enabled:
            fill_color = (60, 60, 60)
        else:
            fill_color = (25, 25, 25)
        cv2.rectangle(output, (x1, y1), (x2, y2), fill_color, -1)
        cv2.rectangle(output, (x1, y1), (x2, y2), (220, 220, 220), 1)
        cv2.putText(
            output,
            name.upper(),
            (x1 + 7, y1 + int(button.height * 0.68)),
            cv2.FONT_HERSHEY_SIMPLEX,
            scale,
            (255, 255, 255) if enabled else (100, 100, 100),
            text_thickness,
            cv2.LINE_AA,
        )

    status_text = format_status_text(mode, pieces, threshold, status_message)
    status_height = max(24, int(round(frame_height * 0.065)))
    cv2.rectangle(
        output,
        (0, frame_height - status_height),
        (frame_width, frame_height),
        (0, 0, 0),
        -1,
    )
    cv2.putText(
        output,
        status_text[:96],
        (8, frame_height - 7),
        cv2.FONT_HERSHEY_SIMPLEX,
        scale,
        (255, 255, 255),
        text_thickness,
        cv2.LINE_AA,
    )
    return output


def run_app():
    """初始化 MaixCAM2 并运行识别与调参双界面主循环。

    主要流程：加载持久现场参数、读取固定相机画面、按RUN或CAL选择参数，处理同一个
    CAL按钮的往返切换，再显示正常识别叠加或ROI/MASK/RESULT调参画面。
    关键参数：无；默认算法来自 config.DEFAULT_CONFIG，现场参数来自持久JSON。
    返回值：正常退出应用时返回 None。
    """
    from maix import app, camera, display, image, time, touchscreen

    camera_width = int(DEFAULT_CONFIG["camera_width"])
    camera_height = int(DEFAULT_CONFIG["camera_height"])
    frame_size = (camera_width, camera_height)
    template_path = PERSISTENT_TEMPLATE_PATH

    disp = display.Display()
    cam = camera.Camera(camera_width, camera_height, image.Format.FMT_BGR888)
    cam.skip_frames(30)
    touch = touchscreen.TouchScreen()
    touch_tracker = TouchReleaseTracker()
    run_buttons = build_button_layout(camera_width, camera_height)
    calibration_buttons = build_calibration_layout(camera_width, camera_height)
    interface_state = InterfaceState()
    planner_runtime = AssemblyRuntime(stable_frames=3, position_tolerance_mm=2.0)
    known_save_controller = KnownSaveController()

    mode = MODE_UNKNOWN
    status_message = "READY"
    try:
        runtime_settings = load_runtime_settings(
            PERSISTENT_SETTINGS_PATH,
            DEFAULT_CONFIG,
        )
    except Exception as error:
        # 损坏设置不能阻止相机启动，回退默认整帧并把错误类型显示给现场人员。
        runtime_settings = build_default_runtime_settings(DEFAULT_CONFIG)
        status_message = f"SETTINGS ERROR {type(error).__name__}"

    try:
        templates = load_templates(template_path)
    except Exception as error:
        # 模板损坏不能阻止未知模式工作，错误保留在状态栏供现场判断。
        templates = []
        status_message = f"TEMPLATE ERROR {type(error).__name__}"

    while not app.need_exit():
        camera_image = cam.read()
        frame_bgr = image.image2cv(camera_image, ensure_bgr=False, copy=False)

        # CAL使用未保存工作副本，RUN只使用已经保存并生效的参数。
        if interface_state.is_calibrating:
            active_settings = interface_state.calibration_session.settings
        else:
            active_settings = runtime_settings
        roi = tuple(int(value) for value in active_settings["roi"])
        paper_quad = active_settings.get("paper_quad")
        active_quad = None

        try:
            analysis = analyze_quad_frame(frame_bgr, active_settings)
            detection = analysis.detection
            roi = analysis.roi
            active_quad = analysis.active_quad
            if paper_quad is None and status_message in ("READY", "RUN MODE"):
                status_message = "ROI NOT SET"
        except Exception as error:
            # 创建与ROI同尺寸的空诊断结果，使调参界面仍能显示并允许按CAL退出。
            roi_x, roi_y, roi_width, roi_height = roi
            empty_mask = cv2.cvtColor(
                frame_bgr[
                    roi_y : roi_y + roi_height,
                    roi_x : roi_x + roi_width,
                ],
                cv2.COLOR_BGR2GRAY,
            )
            empty_mask[:] = 0
            detection = DetectionResult(
                [],
                empty_mask,
                0.0,
                roi,
                valid_contour_count=0,
                white_ratio=0.0,
            )
            status_message = f"VISION ERROR {type(error).__name__}"

        pieces = detection.pieces
        threshold = detection.threshold
        work_region_mm = (
            runtime_settings["work_x_mm"],
            runtime_settings["work_y_mm"],
            runtime_settings["work_width_mm"],
            runtime_settings["work_height_mm"],
        )
        # 触摸动作的结果在当前帧优先于规划状态，尤其不能把SAVE失败原因覆盖掉。
        preserve_planning_status = False
        active_buttons = (
            calibration_buttons if interface_state.is_calibrating else run_buttons
        )

        touch_x, touch_y, pressed = touch.read()
        clicked_display = touch_tracker.update(touch_x, touch_y, pressed)
        if clicked_display is not None:
            clicked_image = map_display_to_image(
                clicked_display,
                (camera_width, camera_height),
                (disp.width(), disp.height()),
            )
            action = hit_test(clicked_image, active_buttons)
            if action == "cal":
                # CAL会改变纸张或分割参数，进入和退出都必须丢弃旧机械目标。
                planner_runtime.reset()
                known_save_controller.cancel()
                entered_calibration = interface_state.toggle_calibration(
                    runtime_settings,
                    frame_size,
                )
                status_message = "CAL MODE" if entered_calibration else "RUN MODE"
            elif interface_state.is_calibrating and action is not None:
                try:
                    runtime_settings, status_message = handle_calibration_action(
                        action,
                        interface_state,
                        runtime_settings,
                        detection,
                        PERSISTENT_SETTINGS_PATH,
                        frame_size,
                        frame_bgr=frame_bgr,
                    )
                except Exception as error:
                    # 调参动作失败保持旧运行参数和当前会话，便于用户修正后重试。
                    status_message = f"CAL ERROR {type(error).__name__}"
            elif action == MODE_KNOWN:
                known_save_controller.cancel()
                if mode != MODE_KNOWN:
                    planner_runtime.reset()
                mode = MODE_KNOWN
                status_message = "KNOWN MODE"
            elif action == MODE_UNKNOWN:
                known_save_controller.cancel()
                if mode != MODE_UNKNOWN:
                    planner_runtime.reset()
                mode = MODE_UNKNOWN
                status_message = "UNKNOWN MODE"
            elif action == "save" and mode == MODE_KNOWN:
                # 触摸回调只创建任务；搜索和文件写入由后续画面逐帧推进。
                planner_runtime.reset()
                status_message = known_save_controller.start(
                    pieces,
                    work_region_mm,
                    runtime_settings["split_y_mm"],
                )
                preserve_planning_status = True

        if interface_state.is_calibrating:
            quality = evaluate_calibration(detection)
            display_frame = draw_calibration_frame(
                frame_bgr,
                detection,
                interface_state.calibration_session,
                calibration_buttons,
                quality,
                status_message,
            )
        else:
            assembly_plan = None
            if mode == MODE_KNOWN:
                templates, template_error = match_known_pieces_safely(
                    pieces,
                    templates,
                    max_score=float(DEFAULT_CONFIG["known_match_threshold"]),
                )
                if template_error is not None:
                    planner_runtime.reset()
                    known_save_controller.cancel()
                    status_message = template_error
                status_message = select_known_template_status(
                    templates,
                    status_message,
                    save_active=known_save_controller.active,
                )
            else:
                assign_unknown_ids(
                    pieces,
                    row_tolerance_px=max(20, camera_height * 0.08),
                )

            save_was_active = known_save_controller.active
            if save_was_active:
                templates, assembly_plan, status_message = known_save_controller.advance(
                    templates,
                    template_path,
                    planner_runtime,
                )
                preserve_planning_status = True
            else:
                assembly_plan = planner_runtime.update(
                    mode,
                    pieces,
                    templates,
                    work_region_mm,
                    runtime_settings["split_y_mm"],
                    known_match_threshold=float(DEFAULT_CONFIG["known_match_threshold"]),
                )
                status_message = select_planning_status(
                    status_message,
                    assembly_plan,
                    planner_runtime.stable_count,
                    planner_runtime.stable_frames,
                    preserve_current=preserve_planning_status,
                    solving=planner_runtime.is_solving,
                    search_nodes=planner_runtime.search_nodes,
                )

            # CAL退出后立即使用已保存ROI画框；当前帧结果最迟在下一帧同步该参数。
            display_roi = tuple(int(value) for value in runtime_settings["roi"])
            display_frame = draw_overlay(
                frame_bgr,
                pieces,
                display_roi,
                run_buttons,
                mode,
                threshold,
                status_message,
                paper_quad=runtime_settings.get("paper_quad"),
                active_quad=build_runtime_active_quad(runtime_settings),
                work_region_mm=work_region_mm,
                split_y_mm=runtime_settings["split_y_mm"],
                assembly_plan=assembly_plan,
            )
        display_image = image.cv2image(display_frame, bgr=True, copy=False)
        disp.show(display_image, fit=image.Fit.FIT_CONTAIN)
        time.sleep_ms(1)


if __name__ == "__main__":
    run_app()
